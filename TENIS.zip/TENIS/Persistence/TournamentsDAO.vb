﻿Public Class TournamentsDAO

    Public ReadOnly Property Tournaments As Collection

    Public Sub New()
        Me.Tournaments = New Collection
    End Sub

    Public Sub ReadAll()
        Dim t As Tournament
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT * FROM Tournaments ORDER BY idTournament ")
        For Each aux In col
            t = New Tournament(aux(1).ToString)
            t.tournamentName = aux(2).ToString
            t.TournamentCity = aux(3).ToString
            t.tournamentCountry = aux(4).ToString
            Me.Tournaments.Add(t)
        Next
    End Sub

    Public Sub Read(ByRef t As Tournament)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Tournaments WHERE idTournament='" & t.idTournament & "';")
        For Each aux In col
            t.TournamentName = aux(2).ToString
            t.TournamentCity = aux(3).ToString
            t.TournamentCountry = aux(4).ToString
        Next
    End Sub

    Public Function Insert(ByVal t As Tournament) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Tournaments VALUES ('" & t.TournamentName & "', '" & t.TournamentCity & "', '" & t.TournamentCountry & "');")
    End Function

    Public Function Update(ByVal t As Tournament) As Integer
        Return DBBroker.GetBroker.Change("UPDATE Tournaments SET TournamentName='" & t.TournamentName & "', TournamentCity= '" & t.TournamentCity & "', TournamentCountry= '" & t.TournamentCountry & "' WHERE idTournament='" & t.idTournament & "';")
    End Function

    Public Function Delete(ByVal t As Tournament) As Integer
        Return DBBroker.GetBroker.Change("DELETE FROM Tournaments WHERE idTournament='" & t.idTournament & "';")
    End Function

End Class
