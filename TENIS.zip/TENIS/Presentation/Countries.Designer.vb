﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Countries
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuBT = New System.Windows.Forms.Button()
        Me.Country = New System.Windows.Forms.Label()
        Me.CountryTB = New System.Windows.Forms.TextBox()
        Me.ClearBT = New System.Windows.Forms.Button()
        Me.DeleteBT = New System.Windows.Forms.Button()
        Me.UpdateBT = New System.Windows.Forms.Button()
        Me.InsertBT = New System.Windows.Forms.Button()
        Me.listaID = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'MenuBT
        '
        Me.MenuBT.Location = New System.Drawing.Point(22, 17)
        Me.MenuBT.Name = "MenuBT"
        Me.MenuBT.Size = New System.Drawing.Size(75, 23)
        Me.MenuBT.TabIndex = 28
        Me.MenuBT.Text = "Menu"
        Me.MenuBT.UseVisualStyleBackColor = True
        '
        'Country
        '
        Me.country.AutoSize = True
        Me.country.Location = New System.Drawing.Point(358, 146)
        Me.country.Name = "Country"
        Me.country.Size = New System.Drawing.Size(57, 17)
        Me.country.TabIndex = 26
        Me.country.Text = "Country"
        '
        'CountryTB
        '
        Me.CountryTB.Location = New System.Drawing.Point(355, 170)
        Me.CountryTB.Name = "CountryTB"
        Me.CountryTB.Size = New System.Drawing.Size(128, 22)
        Me.CountryTB.TabIndex = 22
        '
        'ClearBT
        '
        Me.ClearBT.Location = New System.Drawing.Point(501, 350)
        Me.ClearBT.Name = "ClearBT"
        Me.ClearBT.Size = New System.Drawing.Size(75, 32)
        Me.ClearBT.TabIndex = 19
        Me.ClearBT.Text = "Clear"
        Me.ClearBT.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ClearBT.UseVisualStyleBackColor = True
        '
        'DeleteBT
        '
        Me.DeleteBT.Location = New System.Drawing.Point(355, 350)
        Me.DeleteBT.Name = "DeleteBT"
        Me.DeleteBT.Size = New System.Drawing.Size(75, 32)
        Me.DeleteBT.TabIndex = 18
        Me.DeleteBT.Text = "Delete"
        Me.DeleteBT.UseVisualStyleBackColor = True
        '
        'UpdateBT
        '
        Me.UpdateBT.Location = New System.Drawing.Point(501, 277)
        Me.UpdateBT.Name = "UpdateBT"
        Me.UpdateBT.Size = New System.Drawing.Size(75, 40)
        Me.UpdateBT.TabIndex = 17
        Me.UpdateBT.Text = "Update"
        Me.UpdateBT.UseVisualStyleBackColor = True
        '
        'InsertBT
        '
        Me.InsertBT.Location = New System.Drawing.Point(355, 277)
        Me.InsertBT.Name = "InsertBT"
        Me.InsertBT.Size = New System.Drawing.Size(75, 39)
        Me.InsertBT.TabIndex = 16
        Me.InsertBT.Text = "Insert"
        Me.InsertBT.UseVisualStyleBackColor = True
        '
        'listaID
        '
        Me.listaID.FormattingEnabled = True
        Me.listaID.ItemHeight = 16
        Me.listaID.Location = New System.Drawing.Point(73, 70)
        Me.listaID.Name = "listaID"
        Me.listaID.Size = New System.Drawing.Size(192, 340)
        Me.listaID.TabIndex = 15
        '
        'Countries
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.MenuBT)
        Me.Controls.Add(Me.country)
        Me.Controls.Add(Me.CountryTB)
        Me.Controls.Add(Me.ClearBT)
        Me.Controls.Add(Me.DeleteBT)
        Me.Controls.Add(Me.UpdateBT)
        Me.Controls.Add(Me.InsertBT)
        Me.Controls.Add(Me.listaID)
        Me.Name = "Countries"
        Me.Text = "Countries"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuBT As Button
    Friend WithEvents Country As Label
    Friend WithEvents CountryTB As TextBox
    Friend WithEvents ClearBT As Button
    Friend WithEvents DeleteBT As Button
    Friend WithEvents UpdateBT As Button
    Friend WithEvents InsertBT As Button
    Friend WithEvents listaID As ListBox
End Class
