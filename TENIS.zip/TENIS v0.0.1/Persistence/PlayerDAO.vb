﻿Public Class PlayerDAO

    Public ReadOnly Property Players As Collection

    Public Sub New()
        Me.Players = New Collection
    End Sub

    Public Sub ReadAll()
        Dim p As Player
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT * FROM Players ORDER BY idPlayer")
        For Each aux In col
            p = New Player(aux(1).ToString)
            p.PlayerName = aux(2).ToString
            p.PlayerBirthdate = aux(3).ToString
            p.PlayerPoints = aux(4).ToString
            p.PlayerCountry = aux(5).ToString
            Me.Players.Add(p)
        Next
    End Sub

    Public Sub Read(ByRef p As Player)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Players WHERE idPlayer='" & p.idPlayer & "';")
        For Each aux In col
            p.PlayerName = aux(2).ToString
            p.PlayerBirthdate = aux(3).ToString
            p.PlayerPoints = aux(4).ToString
            p.PlayerCountry = aux(5).ToString
        Next
    End Sub

    Public Function Insert(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Players VALUES ('" & p.idPlayer & "','" & p.PlayerName & "', '" & p.PlayerBirthdate.ToString("yyyy/MM/dd") & "', '" & p.PlayerPoints & "', '" & p.PlayerCountry & "');")
    End Function

    Public Function Update(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("UPDATE Players SET PlayerName='" & p.PlayerName & "', PlayerBirthdate= '" & p.PlayerBirthdate.ToString("yyyy/MM/dd") & "', PlayerPoints= '" & p.PlayerPoints & "', PlayerCountry= '" & p.PlayerCountry & "' WHERE idPlayer='" & p.idPlayer & "';")
    End Function

    Public Function Delete(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("DELETE FROM Players WHERE idPlayer='" & p.idPlayer & "';")
    End Function

End Class
