﻿Public Class CountryDAO

    Public ReadOnly Property Countries_coll As Collection

    Public Sub New()
        Me.Countries_coll = New Collection
    End Sub

    Public Sub ReadAll()
        Dim c As Country
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT * FROM Countries ORDER BY idCountry")
        For Each aux In col
            c = New Country(aux(1).ToString)
            c.CountryName = aux(2).ToString
            Me.Countries_coll.Add(c)
        Next
    End Sub

    Public Sub Read(ByRef c As Country)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Countries WHERE idCountry='" & c.idCountry & "';")
        For Each aux In col
            c.CountryName = aux(2).ToString
        Next
    End Sub

    Public Function Insert(ByVal c As Country) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Countries VALUES ('" & c.idCountry & "', '" & c.CountryName & "');")
    End Function

    Public Sub ReadByName(ByRef c As Country)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Countries WHERE CountryName='" & c.CountryName & "';")
        For Each aux In col
            c.idCountry = aux(1).ToString
        Next
    End Sub

    Public Function Update(ByVal c As Country) As Integer
        Return DBBroker.GetBroker.Change("UPDATE Countries SET CountryName='" & c.CountryName & "' WHERE idCountry='" & c.idCountry & "';")
    End Function

    Public Function Delete(ByVal c As Country) As Integer
        Return DBBroker.GetBroker.Change("DELETE FROM Countries WHERE idCountry='" & c.idCountry & "';")
    End Function

End Class
