﻿Public Class MatchesDAO

    Public ReadOnly Property Matches As Collection

    Public Sub New()
        Me.Matches = New Collection
    End Sub

    Public Sub ReadAll()
        Dim m As Matches
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT * FROM Matches ORDER BY idMatch")
        For Each aux In col
            m = New Matches(aux(1).ToString)
            m.year = aux(2).ToString
            m.tournament = aux(3).ToString
            m.winner = aux(4).ToString
            m.round = aux(5).ToString
            Me.Matches.Add(m)
        Next
    End Sub

    Public Sub Read(ByRef m As Matches)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Matches WHERE idMatch='" & m.idMatch & "';")
        For Each aux In col
            m.year = aux(2).ToString
            m.winner = aux(3).ToString
            m.round = aux(4).ToString
        Next
    End Sub

    Public Function Insert(ByVal m As Matches) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Matches VALUES ('" & m.idMatch & "', '" & m.year & "', '" & m.tournament & "', '" & m.winner & "', '" & m.round & "');")
    End Function

    Public Function Update(ByVal m As Matches) As Integer
        Return DBBroker.GetBroker.Change("UPDATE Matches SET year='" & m.year & "', Tournament= '" & m.tournament & "', Winner= '" & m.winner & "', Round= '" & m.round & "' WHERE idPlayer='" & m.idMatch & "';")
    End Function

    Public Function Delete(ByVal m As Matches) As Integer
        Return DBBroker.GetBroker.Change("DELETE FROM Matches WHERE idMatch='" & m.idMatch & "';")
    End Function

End Class
