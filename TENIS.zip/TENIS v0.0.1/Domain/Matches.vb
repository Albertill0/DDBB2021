﻿Public Class Matches

    Public Property idMatch As Integer
    Public Property year As Integer
    Public Property tournament As Integer
    Public Property winner As Integer
    Public Property round As Char


    Public ReadOnly Property MatchesDAO As MatchesDAO

    Public Sub New()
        Me.MatchesDAO = New MatchesDAO
    End Sub

    Public Sub New(id As String)
        Me.MatchesDAO = New MatchesDAO
        Me.idMatch = id
    End Sub

    Public Sub ReadAllMatches()
        Me.MatchesDAO.ReadAll()
    End Sub
    Public Sub ReadMatch()
        Me.MatchesDAO.Read(Me)
    End Sub

    Public Function InsertMatch() As Integer
        Return Me.MatchesDAO.Insert(Me)
    End Function

    Public Function UpdateMatch() As Integer
        Return Me.MatchesDAO.Update(Me)
    End Function

    Public Function DeleteMatch() As Integer
        Return Me.MatchesDAO.Delete(Me)
    End Function

End Class
