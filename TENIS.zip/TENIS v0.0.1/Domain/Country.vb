﻿Public Class Country

    Public Property idCountry As String
    Public Property CountryName As String

    Public ReadOnly Property CountriesDAO As CountryDAO

    Public Sub New()
        Me.CountriesDAO = New CountryDAO
    End Sub

    Public Sub New(id As String)
        Me.CountriesDAO = New CountryDAO
        Me.idCountry = id
    End Sub

    Public Sub ReadAllCountries()
        Me.CountriesDAO.ReadAll()
    End Sub
    Public Sub ReadCountry()
        Me.CountriesDAO.Read(Me)
    End Sub

    Public Function InsertCountry() As Integer
        Return Me.CountriesDAO.Insert(Me)
    End Function

    Public Function UpdateCountry() As Integer
        Return Me.CountriesDAO.Update(Me)
    End Function

    Public Function DeleteCountry() As Integer
        Return Me.CountriesDAO.Delete(Me)
    End Function

    Friend Sub ReadCountryByName()
        Me.CountriesDAO.ReadByName(Me)
    End Sub
End Class
