﻿Public Class Tournament
    Public Property idTournament As Integer
    Public Property TournamentName As String
    Public Property TournamentCity As String
    Public Property TournamentCountry As String
    Public ReadOnly Property TournamentDAO As TournamentsDAO

    Public Sub New()
        Me.TournamentDAO = New TournamentsDAO
    End Sub

    Public Sub New(id As String)
        Me.TournamentDAO = New TournamentsDAO
        Me.idTournament = id
    End Sub

    Public Sub ReadAllTournaments()
        Me.TournamentDAO.ReadAll()
    End Sub
    Public Sub ReadTournament()
        Me.TournamentDAO.Read(Me)
    End Sub

    Public Function InsertTournament() As Integer
        Return Me.TournamentDAO.Insert(Me)
    End Function

    Public Function UpdateTournament() As Integer
        Return Me.TournamentDAO.Update(Me)
    End Function

    Public Function DeleteTournament() As Integer
        Return Me.TournamentDAO.Delete(Me)
    End Function
End Class
