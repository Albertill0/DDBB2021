﻿Public Class Player

    Public Property idPlayer As Integer
    Public Property PlayerName As String
    Public Property PlayerBirthdate As Date
    Public Property PlayerPoints As Integer

    Public Property PlayerCountry As String

    Public ReadOnly Property PlayerDAO As PlayerDAO

    Public Sub New()
        Me.PlayerDAO = New PlayerDAO
    End Sub

    Public Sub New(id As String)
        Me.PlayerDAO = New PlayerDAO
        Me.idPlayer = id
    End Sub

    Public Sub ReadAllPlayers()
        Me.PlayerDAO.ReadAll()
    End Sub
    Public Sub ReadPlayer()
        Me.PlayerDAO.Read(Me)
    End Sub

    Public Function InsertPlayer() As Integer
        Return Me.PlayerDAO.Insert(Me)
    End Function

    Public Function UpdatePlayer() As Integer
        Return Me.PlayerDAO.Update(Me)
    End Function

    Public Function DeletePlayer() As Integer
        Return Me.PlayerDAO.Delete(Me)
    End Function

End Class
