﻿Public Class Countries

    Private countryEntity As Country

    Private Sub MenuBT_Click(sender As Object, e As EventArgs) Handles MenuBT.Click
        Dim Main As New Main_Interface()
        Main.Activate()
        Main.ConnectionB.Enabled = False
        Main.playerB.Enabled = True
        Main.countryB.Enabled = True
        Main.tournamentB.Enabled = True
        Main.Show()
        Me.Hide()
    End Sub

    Private Sub listaID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaID.SelectedIndexChanged
        countryEntity = New Country With {
          .idCountry = listaID.SelectedItem
      }
        Try
            countryEntity.ReadCountry()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        idTB.Text = countryEntity.idCountry
        CountryTB.Text = countryEntity.CountryName
        InsertBT.Enabled = False
        ClearBT.Enabled = True
        UpdateBT.Enabled = True
        DeleteBT.Enabled = True
        idTB.Enabled = False
    End Sub

    Private Sub InsertBT_Click(sender As Object, e As EventArgs) Handles InsertBT.Click
        countryEntity = New Country With {
            .idCountry = idTB.Text,
            .CountryName = CountryTB.Text
        }

        Try
            countryEntity.InsertCountry()
            MessageBox.Show("Added country")
            listaID.Items.Add(countryEntity.idCountry)
            listaID.Refresh()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try

    End Sub

    Private Sub UpdateBT_Click(sender As Object, e As EventArgs) Handles UpdateBT.Click
        countryEntity = New Country()
        countryEntity.idCountry = listaID.SelectedItem
        countryEntity.CountryName = CountryTB.Text
        Try
            countryEntity.UpdateCountry()
            MessageBox.Show("Updated country properly")
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try



    End Sub

    Private Sub DeleteBT_Click(sender As Object, e As EventArgs) Handles DeleteBT.Click
        countryEntity = New Country With {
            .idCountry = listaID.SelectedItem
        }

        Try
            countryEntity.DeleteCountry()
            MessageBox.Show("Deleted country properly")
            listaID.Items.Remove(listaID.SelectedItem)
            listaID.Refresh()
            idTB.Text = ""
            CountryTB.Text = ""
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try

    End Sub

    Private Sub ClearBT_Click(sender As Object, e As EventArgs) Handles ClearBT.Click
        CountryTB.Text = ""
        idTB.Text = ""
        UpdateBT.Enabled = False
        InsertBT.Enabled = True
        DeleteBT.Enabled = False
        idTB.Enabled = True
    End Sub

    Private Sub Countries_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aux As Country
        countryEntity = New Country()
        Try
            countryEntity.ReadAllCountries()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        idTB.MaxLength = 3
        InsertBT.Enabled = True
        DeleteBT.Enabled = False
        UpdateBT.Enabled = False
        ClearBT.Enabled = True
        For Each aux In countryEntity.CountriesDAO.Countries_coll
            listaID.Items.Add(aux.idCountry)
        Next
        listaID.Refresh()
    End Sub
End Class