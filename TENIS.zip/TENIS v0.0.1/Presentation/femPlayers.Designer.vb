﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class femPlayers
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.listaID = New System.Windows.Forms.ListBox()
        Me.InsertBT = New System.Windows.Forms.Button()
        Me.UpdateBT = New System.Windows.Forms.Button()
        Me.DeleteBT = New System.Windows.Forms.Button()
        Me.ClearBT = New System.Windows.Forms.Button()
        Me.NameTB = New System.Windows.Forms.TextBox()
        Me.PointsTB = New System.Windows.Forms.TextBox()
        Me.PlayernameLB = New System.Windows.Forms.Label()
        Me.PointsLabel = New System.Windows.Forms.Label()
        Me.DateLabel = New System.Windows.Forms.Label()
        Me.Country = New System.Windows.Forms.Label()
        Me.birthpicker = New System.Windows.Forms.DateTimePicker()
        Me.MenuBT = New System.Windows.Forms.Button()
        Me.comboCountries = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'listaID
        '
        Me.listaID.FormattingEnabled = True
        Me.listaID.ItemHeight = 16
        Me.listaID.Location = New System.Drawing.Point(63, 65)
        Me.listaID.Name = "listaID"
        Me.listaID.Size = New System.Drawing.Size(192, 340)
        Me.listaID.TabIndex = 0
        '
        'InsertBT
        '
        Me.InsertBT.Location = New System.Drawing.Point(345, 272)
        Me.InsertBT.Name = "InsertBT"
        Me.InsertBT.Size = New System.Drawing.Size(75, 39)
        Me.InsertBT.TabIndex = 1
        Me.InsertBT.Text = "Insert"
        Me.InsertBT.UseVisualStyleBackColor = True
        '
        'UpdateBT
        '
        Me.UpdateBT.Location = New System.Drawing.Point(491, 272)
        Me.UpdateBT.Name = "UpdateBT"
        Me.UpdateBT.Size = New System.Drawing.Size(75, 40)
        Me.UpdateBT.TabIndex = 2
        Me.UpdateBT.Text = "Update"
        Me.UpdateBT.UseVisualStyleBackColor = True
        '
        'DeleteBT
        '
        Me.DeleteBT.Location = New System.Drawing.Point(345, 345)
        Me.DeleteBT.Name = "DeleteBT"
        Me.DeleteBT.Size = New System.Drawing.Size(75, 32)
        Me.DeleteBT.TabIndex = 3
        Me.DeleteBT.Text = "Delete"
        Me.DeleteBT.UseVisualStyleBackColor = True
        '
        'ClearBT
        '
        Me.ClearBT.Location = New System.Drawing.Point(491, 345)
        Me.ClearBT.Name = "ClearBT"
        Me.ClearBT.Size = New System.Drawing.Size(75, 32)
        Me.ClearBT.TabIndex = 4
        Me.ClearBT.Text = "Clear"
        Me.ClearBT.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ClearBT.UseVisualStyleBackColor = True
        '
        'NameTB
        '
        Me.NameTB.Location = New System.Drawing.Point(320, 127)
        Me.NameTB.Name = "NameTB"
        Me.NameTB.Size = New System.Drawing.Size(100, 22)
        Me.NameTB.TabIndex = 5
        '
        'PointsTB
        '
        Me.PointsTB.Location = New System.Drawing.Point(320, 180)
        Me.PointsTB.Name = "PointsTB"
        Me.PointsTB.Size = New System.Drawing.Size(100, 22)
        Me.PointsTB.TabIndex = 6
        '
        'PlayernameLB
        '
        Me.PlayernameLB.AutoSize = True
        Me.PlayernameLB.Location = New System.Drawing.Point(320, 85)
        Me.PlayernameLB.Name = "PlayernameLB"
        Me.PlayernameLB.Size = New System.Drawing.Size(85, 17)
        Me.PlayernameLB.TabIndex = 9
        Me.PlayernameLB.Text = "PlayerName"
        '
        'PointsLabel
        '
        Me.PointsLabel.AutoSize = True
        Me.PointsLabel.Location = New System.Drawing.Point(323, 156)
        Me.PointsLabel.Name = "PointsLabel"
        Me.PointsLabel.Size = New System.Drawing.Size(98, 17)
        Me.PointsLabel.TabIndex = 10
        Me.PointsLabel.Text = "Current Points"
        '
        'DateLabel
        '
        Me.DateLabel.AutoSize = True
        Me.DateLabel.Location = New System.Drawing.Point(494, 85)
        Me.DateLabel.Name = "DateLabel"
        Me.DateLabel.Size = New System.Drawing.Size(60, 17)
        Me.DateLabel.TabIndex = 11
        Me.DateLabel.Text = "Birthday"
        '
        'Country
        '
        Me.Country.AutoSize = True
        Me.Country.Location = New System.Drawing.Point(497, 156)
        Me.Country.Name = "Country"
        Me.Country.Size = New System.Drawing.Size(57, 17)
        Me.Country.TabIndex = 12
        Me.Country.Text = "Country"
        '
        'birthpicker
        '
        Me.birthpicker.CustomFormat = "yyyy/MM/dd"
        Me.birthpicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.birthpicker.Location = New System.Drawing.Point(491, 127)
        Me.birthpicker.Name = "birthpicker"
        Me.birthpicker.Size = New System.Drawing.Size(121, 22)
        Me.birthpicker.TabIndex = 13
        '
        'MenuBT
        '
        Me.MenuBT.Location = New System.Drawing.Point(12, 12)
        Me.MenuBT.Name = "MenuBT"
        Me.MenuBT.Size = New System.Drawing.Size(75, 23)
        Me.MenuBT.TabIndex = 14
        Me.MenuBT.Text = "Menu"
        Me.MenuBT.UseVisualStyleBackColor = True
        '
        'comboCountries
        '
        Me.comboCountries.FormattingEnabled = True
        Me.comboCountries.Location = New System.Drawing.Point(491, 180)
        Me.comboCountries.Name = "comboCountries"
        Me.comboCountries.Size = New System.Drawing.Size(121, 24)
        Me.comboCountries.TabIndex = 15
        '
        'femPlayers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.comboCountries)
        Me.Controls.Add(Me.MenuBT)
        Me.Controls.Add(Me.birthpicker)
        Me.Controls.Add(Me.Country)
        Me.Controls.Add(Me.DateLabel)
        Me.Controls.Add(Me.PointsLabel)
        Me.Controls.Add(Me.PlayernameLB)
        Me.Controls.Add(Me.PointsTB)
        Me.Controls.Add(Me.NameTB)
        Me.Controls.Add(Me.ClearBT)
        Me.Controls.Add(Me.DeleteBT)
        Me.Controls.Add(Me.UpdateBT)
        Me.Controls.Add(Me.InsertBT)
        Me.Controls.Add(Me.listaID)
        Me.Name = "femPlayers"
        Me.Text = "femPlayers"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents listaID As ListBox
    Friend WithEvents InsertBT As Button
    Friend WithEvents UpdateBT As Button
    Friend WithEvents DeleteBT As Button
    Friend WithEvents ClearBT As Button
    Friend WithEvents NameTB As TextBox
    Friend WithEvents PointsTB As TextBox
    Friend WithEvents PlayernameLB As Label
    Friend WithEvents PointsLabel As Label
    Friend WithEvents DateLabel As Label
    Friend WithEvents Country As Label
    Friend WithEvents birthpicker As DateTimePicker
    Friend WithEvents MenuBT As Button
    Friend WithEvents comboCountries As ComboBox
End Class
