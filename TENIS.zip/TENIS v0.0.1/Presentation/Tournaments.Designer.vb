﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Tournaments
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuBT = New System.Windows.Forms.Button()
        Me.Country = New System.Windows.Forms.Label()
        Me.Citylabel = New System.Windows.Forms.Label()
        Me.tournamentnameLB = New System.Windows.Forms.Label()
        Me.CityTB = New System.Windows.Forms.TextBox()
        Me.NameTB = New System.Windows.Forms.TextBox()
        Me.ClearBT = New System.Windows.Forms.Button()
        Me.DeleteBT = New System.Windows.Forms.Button()
        Me.UpdateBT = New System.Windows.Forms.Button()
        Me.InsertBT = New System.Windows.Forms.Button()
        Me.listaID = New System.Windows.Forms.ListBox()
        Me.ComboCountry = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'MenuBT
        '
        Me.MenuBT.Location = New System.Drawing.Point(24, 18)
        Me.MenuBT.Name = "MenuBT"
        Me.MenuBT.Size = New System.Drawing.Size(75, 23)
        Me.MenuBT.TabIndex = 28
        Me.MenuBT.Text = "Menu"
        Me.MenuBT.UseVisualStyleBackColor = True
        '
        'Country
        '
        Me.Country.AutoSize = True
        Me.Country.Location = New System.Drawing.Point(485, 91)
        Me.Country.Name = "Country"
        Me.Country.Size = New System.Drawing.Size(57, 17)
        Me.Country.TabIndex = 26
        Me.Country.Text = "Country"
        '
        'Citylabel
        '
        Me.Citylabel.AutoSize = True
        Me.Citylabel.Location = New System.Drawing.Point(335, 162)
        Me.Citylabel.Name = "Citylabel"
        Me.Citylabel.Size = New System.Drawing.Size(31, 17)
        Me.Citylabel.TabIndex = 24
        Me.Citylabel.Text = "City"
        '
        'tournamentnameLB
        '
        Me.tournamentnameLB.AutoSize = True
        Me.tournamentnameLB.Location = New System.Drawing.Point(332, 91)
        Me.tournamentnameLB.Name = "tournamentnameLB"
        Me.tournamentnameLB.Size = New System.Drawing.Size(122, 17)
        Me.tournamentnameLB.TabIndex = 23
        Me.tournamentnameLB.Text = "TournamentName"
        '
        'CityTB
        '
        Me.CityTB.Location = New System.Drawing.Point(332, 186)
        Me.CityTB.Name = "CityTB"
        Me.CityTB.Size = New System.Drawing.Size(100, 22)
        Me.CityTB.TabIndex = 21
        '
        'NameTB
        '
        Me.NameTB.Location = New System.Drawing.Point(332, 133)
        Me.NameTB.Name = "NameTB"
        Me.NameTB.Size = New System.Drawing.Size(100, 22)
        Me.NameTB.TabIndex = 20
        '
        'ClearBT
        '
        Me.ClearBT.Location = New System.Drawing.Point(503, 351)
        Me.ClearBT.Name = "ClearBT"
        Me.ClearBT.Size = New System.Drawing.Size(75, 32)
        Me.ClearBT.TabIndex = 19
        Me.ClearBT.Text = "Clear"
        Me.ClearBT.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ClearBT.UseVisualStyleBackColor = True
        '
        'DeleteBT
        '
        Me.DeleteBT.Location = New System.Drawing.Point(357, 351)
        Me.DeleteBT.Name = "DeleteBT"
        Me.DeleteBT.Size = New System.Drawing.Size(75, 32)
        Me.DeleteBT.TabIndex = 18
        Me.DeleteBT.Text = "Delete"
        Me.DeleteBT.UseVisualStyleBackColor = True
        '
        'UpdateBT
        '
        Me.UpdateBT.Location = New System.Drawing.Point(503, 278)
        Me.UpdateBT.Name = "UpdateBT"
        Me.UpdateBT.Size = New System.Drawing.Size(75, 40)
        Me.UpdateBT.TabIndex = 17
        Me.UpdateBT.Text = "Update"
        Me.UpdateBT.UseVisualStyleBackColor = True
        '
        'InsertBT
        '
        Me.InsertBT.Location = New System.Drawing.Point(357, 278)
        Me.InsertBT.Name = "InsertBT"
        Me.InsertBT.Size = New System.Drawing.Size(75, 39)
        Me.InsertBT.TabIndex = 16
        Me.InsertBT.Text = "Insert"
        Me.InsertBT.UseVisualStyleBackColor = True
        '
        'listaID
        '
        Me.listaID.FormattingEnabled = True
        Me.listaID.ItemHeight = 16
        Me.listaID.Location = New System.Drawing.Point(75, 71)
        Me.listaID.Name = "listaID"
        Me.listaID.Size = New System.Drawing.Size(192, 340)
        Me.listaID.TabIndex = 15
        '
        'ComboCountry
        '
        Me.ComboCountry.FormattingEnabled = True
        Me.ComboCountry.Location = New System.Drawing.Point(488, 133)
        Me.ComboCountry.Name = "ComboCountry"
        Me.ComboCountry.Size = New System.Drawing.Size(100, 24)
        Me.ComboCountry.TabIndex = 29
        '
        'Tournaments
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.ComboCountry)
        Me.Controls.Add(Me.MenuBT)
        Me.Controls.Add(Me.Country)
        Me.Controls.Add(Me.Citylabel)
        Me.Controls.Add(Me.tournamentnameLB)
        Me.Controls.Add(Me.CityTB)
        Me.Controls.Add(Me.NameTB)
        Me.Controls.Add(Me.ClearBT)
        Me.Controls.Add(Me.DeleteBT)
        Me.Controls.Add(Me.UpdateBT)
        Me.Controls.Add(Me.InsertBT)
        Me.Controls.Add(Me.listaID)
        Me.Name = "Tournaments"
        Me.Text = "Tournaments"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuBT As Button
    Friend WithEvents Country As Label
    Friend WithEvents Citylabel As Label
    Friend WithEvents tournamentnameLB As Label
    Friend WithEvents CityTB As TextBox
    Friend WithEvents NameTB As TextBox
    Friend WithEvents ClearBT As Button
    Friend WithEvents DeleteBT As Button
    Friend WithEvents UpdateBT As Button
    Friend WithEvents InsertBT As Button
    Friend WithEvents listaID As ListBox
    Friend WithEvents ComboCountry As ComboBox
End Class
