﻿Public Class Tournaments
    Private tournament As Tournament
    Private AuxCountry As Country
    Private Sub Tournaments_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aux As Tournament
        tournament = New Tournament()
        Try
            tournament.ReadAllTournaments()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        For Each aux In tournament.TournamentDAO.Tournaments
            listaID.Items.Add(aux.idTournament)
        Next
        listaID.Refresh()
        UpdateBT.Enabled = False
        DeleteBT.Enabled = False
        InsertBT.Enabled = True
        ClearBT.Enabled = True
        Dim auxc As Country
        AuxCountry = New Country()
        Try
            AuxCountry.ReadAllCountries()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        For Each auxc In AuxCountry.CountriesDAO.Countries_coll
            ComboCountry.Items.Add(auxc.idCountry)
        Next
    End Sub

    Private Sub MenuBT_Click(sender As Object, e As EventArgs) Handles MenuBT.Click
        Dim Main As New Main_Interface()
        Main.Activate()
        Main.ConnectionB.Enabled = False
        Main.playerB.Enabled = True
        Main.countryB.Enabled = True
        Main.tournamentB.Enabled = True
        Main.Show()
        Me.Hide()
    End Sub

    Private Sub listaID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaID.SelectedIndexChanged
        tournament = New Tournament With {
            .idTournament = listaID.SelectedItem
        }

        Try
            tournament.ReadTournament()
            NameTB.Text = tournament.TournamentName
            CityTB.Text = tournament.TournamentCity
            ComboCountry.Text = tournament.TournamentCountry
            UpdateBT.Enabled = True
            DeleteBT.Enabled = True

        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try

    End Sub

    Private Sub InsertBT_Click(sender As Object, e As EventArgs) Handles InsertBT.Click
        tournament = New Tournament With {
            .TournamentName = NameTB.Text,
            .TournamentCity = CityTB.Text,
            .TournamentCountry = ComboCountry.Text
        }
        Try
            tournament.InsertTournament()
            'tournament.ReadTournament()
            listaID.Items.Clear()
            Tournaments_Load(sender, e)
            listaID.Refresh()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try

    End Sub

    Private Sub ClearBT_Click(sender As Object, e As EventArgs) Handles ClearBT.Click
        UpdateBT.Enabled = False
        DeleteBT.Enabled = False
        NameTB.Text = ""
        ComboCountry.Text = ""
        CityTB.Text = ""
        InsertBT.Enabled = True
    End Sub

    Private Sub UpdateBT_Click(sender As Object, e As EventArgs) Handles UpdateBT.Click
        tournament = New Tournament With {
            .idTournament = listaID.SelectedItem,
            .TournamentName = NameTB.Text,
            .TournamentCity = CityTB.Text,
            .TournamentCountry = ComboCountry.Text
        }

        Try
            tournament.UpdateTournament()
            MessageBox.Show("Updated tournament properly")
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try

    End Sub

    Private Sub DeleteBT_Click(sender As Object, e As EventArgs) Handles DeleteBT.Click
        tournament = New Tournament With {
            .idTournament = listaID.SelectedItem
        }

        Try
            tournament.DeleteTournament()
            MessageBox.Show("Deleted country properly")
            listaID.Items.Remove(listaID.SelectedItem)
            listaID.Refresh()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
    End Sub
End Class