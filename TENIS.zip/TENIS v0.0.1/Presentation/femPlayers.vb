﻿Public Class femPlayers
    Private femP As Player
    Private AuxCountry As Country
    Private Sub listaNombreJugador_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaID.SelectedIndexChanged
        If listaID.SelectedIndex > -1 Then
            femP = New Player With {
            .idPlayer = listaID.SelectedItem
        }
            Try
                femP.ReadPlayer()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try
            NameTB.Text = femP.PlayerName
            birthpicker.Value = femP.PlayerBirthdate
            PointsTB.Text = femP.PlayerPoints
            comboCountries.Text = femP.PlayerCountry
            InsertBT.Enabled = False
            ClearBT.Enabled = True
            UpdateBT.Enabled = True
            DeleteBT.Enabled = True
            PointsTB.Enabled = True
        End If
    End Sub

    Private Sub InsertBT_Click(sender As Object, e As EventArgs) Handles InsertBT.Click
        femP = New Player With {
            .PlayerName = NameTB.Text,
            .PlayerPoints = Convert.ToInt32(PointsTB.Text),
            .PlayerCountry = comboCountries.Text,
            .PlayerBirthdate = birthpicker.Value.Date
        }
        Try
            femP.InsertPlayer()
            listaID.Items.Clear()
            femPlayers_Load(sender, e)
        Catch ex As Exception
            MessageBox.Show("Impossible to insert player." + ex.Message, ex.Source)
        End Try

    End Sub

    Private Sub femPlayers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aux As Player
        femP = New Player()
        Try
            femP.ReadAllPlayers()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)

        End Try
        For Each aux In femP.PlayerDAO.Players
            listaID.Items.Add(aux.idPlayer)
        Next
        comboCountries.MaxLength = 3
        PointsTB.Text = "0"
        PointsTB.Enabled = False
        InsertBT.Enabled = True
        DeleteBT.Enabled = False
        UpdateBT.Enabled = False
        ClearBT.Enabled = True
        Dim auxc As Country
        AuxCountry = New Country()
        Try
            AuxCountry.ReadAllCountries()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        For Each auxc In AuxCountry.CountriesDAO.Countries_coll
            comboCountries.Items.Add(auxc.idCountry)
        Next
    End Sub

    Private Sub ClearBT_Click(sender As Object, e As EventArgs) Handles ClearBT.Click
        NameTB.Text = ""
        PointsTB.Text = ""
        comboCountries.Text = ""
        InsertBT.Enabled = True
        UpdateBT.Enabled = False
        DeleteBT.Enabled = False
        PointsTB.Text = "0"
        PointsTB.Enabled = False
    End Sub

    Private Sub UpdateBT_Click(sender As Object, e As EventArgs) Handles UpdateBT.Click
        femP = New Player()
        femP.idPlayer = listaID.SelectedItem
        femP.PlayerName = NameTB.Text
        femP.PlayerPoints = PointsTB.Text
        femP.PlayerCountry = comboCountries.Text
        femP.PlayerBirthdate = birthpicker.Value

        Try
            femP.UpdatePlayer()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try

        MessageBox.Show("Player updated properly")
    End Sub

    Private Sub DeleteBT_Click(sender As Object, e As EventArgs) Handles DeleteBT.Click
        femP = New Player()
        femP.idPlayer = listaID.SelectedItem
        Try
            femP.DeletePlayer()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        MessageBox.Show("Deleted properly")
        comboCountries.Text = ""
        NameTB.Text = ""
        PointsTB.Text = "0"
        PointsTB.Enabled = False
        listaID.Items.Remove(listaID.SelectedItem)
        listaID.Refresh()
    End Sub

    Private Sub menu_Click(sender As Object, e As EventArgs) Handles MenuBT.Click
        Dim Main As New Main_Interface()
        Main.Activate()
        Main.ConnectionB.Enabled = False
        Main.playerB.Enabled = True
        Main.countryB.Enabled = True
        Main.tournamentB.Enabled = True
        Main.Show()
        Me.Hide()
    End Sub

    Private Sub comboCountries_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboCountries.SelectedIndexChanged

    End Sub
End Class