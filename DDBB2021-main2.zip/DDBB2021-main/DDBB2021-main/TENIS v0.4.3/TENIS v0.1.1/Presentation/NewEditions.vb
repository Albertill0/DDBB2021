﻿Public Class NewEditions
    Private AuxTournament As Tournament
    Private femPlayer As Player
    Private colPlayers As New Collection
    Private Match As Matches
    Private MatchesCol As New Collection
    Private PlaysCol As New Collection
    Public Sub New(frmTournament As Tournaments)

        ' Esta llamada es exigida por el diseñador.
        InitializeComponent()
        AuxTournament = frmTournament.tournament
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub
    Private Sub NewEditions_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TournamentNameTB.Enabled = False
        genEditionBT.Enabled = False
        TournamentNameTB.Text = AuxTournament.TournamentName
        Dim auxYear, i As Integer
        auxYear = 2022
        For i = 0 To 40
            comboDate.Items.Add(auxYear + i)
        Next
    End Sub

    Private Sub comboDate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboDate.SelectedIndexChanged
        If comboDate.SelectedItem IsNot Nothing Then
            genEditionBT.Enabled = True
        End If
    End Sub

    Private Sub genEditionBT_Click(sender As Object, e As EventArgs) Handles genEditionBT.Click
        comboDate.Enabled = False
        genEditionBT.Enabled = False
        femPlayer = New Player()
        Dim aux As New Player()
        Try
            femPlayer.ReadRandomPlayers()
            For Each aux In femPlayer.PlayerDAO.Players
                colPlayers.Add(aux)
                listPlayers.Items.Add(aux.PlayerName)
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        femPlayer = CType(colPlayers(1), Player)
        PlayerTOP1TB.Text = femPlayer.PlayerName
        femPlayer = CType(colPlayers(8), Player)
        PlayerTOP8TB.Text = femPlayer.PlayerName
        femPlayer = CType(colPlayers(6), Player)
        PlayerTOP6TB.Text = femPlayer.PlayerName
        femPlayer = CType(colPlayers(3), Player)
        PlayerTOP3TB.Text = femPlayer.PlayerName
        femPlayer = CType(colPlayers(4), Player)
        PlayerTOP4TB.Text = femPlayer.PlayerName
        femPlayer = CType(colPlayers(5), Player)
        PlayerTOP5TB.Text = femPlayer.PlayerName
        femPlayer = CType(colPlayers(7), Player)
        PlayerTOP7TB.Text = femPlayer.PlayerName
        femPlayer = CType(colPlayers(2), Player)
        PlayerTOP2TB.Text = femPlayer.PlayerName
        playBT.Enabled = True
    End Sub

    Private Sub listPlayers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listPlayers.SelectedIndexChanged

        If listPlayers.SelectedItem IsNot Nothing Then
            femPlayer.PlayerName = CStr(listPlayers.SelectedItem)
            Try
                femPlayer.ReadPlayerByNamed()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try

            scoreLB.Text = "Score : " + femPlayer.PlayerPoints.ToString
        End If
    End Sub

    Private Sub ResetBT_Click(sender As Object, e As EventArgs) Handles ResetBT.Click
        PlayerTOP1TB.Clear() : PlayerTOP2TB.Clear() : PlayerTOP3TB.Clear() : PlayerTOP4TB.Clear() : PlayerTOP5TB.Clear() : PlayerTOP6TB.Clear()
        PlayerTOP7TB.Clear() : PlayerTOP8TB.Clear() : sem1TB.Clear() : sem2TB.Clear() : sem3TB.Clear() : sem4TB.Clear() : fin1TB.Clear() : fin2TB.Clear() : winnerTB.Clear()
        listPlayers.Items.Clear()
        comboDate.Enabled = True
        playBT.Enabled = False
    End Sub

    Private Sub ReturnBT_Click(sender As Object, e As EventArgs) Handles ReturnBT.Click
        Tournaments.Activate()
        Tournaments.Show()
        Me.Close()
    End Sub

    Private Sub playBT_Click(sender As Object, e As EventArgs) Handles playBT.Click

        Dim semifinalist1, semifinalist2, semifinalist3, semifinalist4, finalist1, finalist2, winner, top1, top2, top3, top4, top5, top6, top7, top8 As Integer
        Dim aux, aux2, aux3, aux4, aux5, aux6, aux7 As New Player
        Dim edition As New Editions
        Dim matchs As New Matches
        Dim matchts As New Matches
        Match = New Matches
        MatchesCol = New Collection
        Dim plays As New RelationPlays
        Dim i As Integer

        Match.year = CInt(comboDate.SelectedItem)
        Match.tournament = AuxTournament.idTournament

        Try
            femPlayer.PlayerName = PlayerTOP1TB.Text
            aux.PlayerName = PlayerTOP8TB.Text
            aux2.PlayerName = PlayerTOP3TB.Text
            aux3.PlayerName = PlayerTOP6TB.Text
            aux4.PlayerName = PlayerTOP4TB.Text
            aux5.PlayerName = PlayerTOP5TB.Text
            aux6.PlayerName = PlayerTOP2TB.Text
            aux7.PlayerName = PlayerTOP7TB.Text

            femPlayer.ReadPlayerByNamed()
            aux.ReadPlayerByNamed()
            aux2.ReadPlayerByNamed()
            aux3.ReadPlayerByNamed()
            aux4.ReadPlayerByNamed()
            aux5.ReadPlayerByNamed()
            aux6.ReadPlayerByNamed()
            aux7.ReadPlayerByNamed()

        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try


        Try
            top1 = femPlayer.idPlayer
            top8 = aux.idPlayer
            semifinalist1 = simulateMatch(top1, top8)
            Match.winner = semifinalist1
            Match.round = CChar("Q")
            MatchesCol.Add(Match)

            femPlayer.idPlayer = semifinalist1
            femPlayer.ReadPlayerByID()

            AdjustPoints(top1, top8, Match.round, semifinalist1)
            sem1TB.Text = femPlayer.PlayerName

            top3 = aux2.idPlayer
            top6 = aux3.idPlayer
            semifinalist3 = simulatematch(top3, top6)
            Match = New Matches
            Match.year = CInt(comboDate.SelectedItem)
            Match.tournament = AuxTournament.idTournament
            Match.winner = semifinalist3
            Match.round = CChar("Q")
            MatchesCol.Add(Match)

            femPlayer.idPlayer = semifinalist3
            femPlayer.ReadPlayerByID()

            AdjustPoints(top3, top6, Match.round, semifinalist3)
            sem3TB.Text = femPlayer.PlayerName

            top4 = aux4.idPlayer
            top5 = aux5.idPlayer
            semifinalist2 = simulatematch(top4, top5)
            Match = New Matches
            Match.year = CInt(comboDate.SelectedItem)
            Match.tournament = AuxTournament.idTournament
            Match.winner = semifinalist2
            Match.round = CChar("Q")
            MatchesCol.Add(Match)

            femPlayer.idPlayer = semifinalist2
            femPlayer.ReadPlayerByID()

            AdjustPoints(top4, top5, Match.round, semifinalist2)
            sem2TB.Text = femPlayer.PlayerName

            top2 = aux6.idPlayer
            top7 = aux7.idPlayer
            semifinalist4 = simulatematch(top2, top7)
            Match = New Matches
            Match.year = CInt(comboDate.SelectedItem)
            Match.tournament = AuxTournament.idTournament
            Match.winner = semifinalist4
            Match.round = CChar("Q")
            MatchesCol.Add(Match)

            femPlayer.idPlayer = semifinalist4
            femPlayer.ReadPlayerByID()

            AdjustPoints(top2, top7, Match.round, semifinalist4)
            sem4TB.Text = femPlayer.PlayerName

            finalist1 = simulatematch(semifinalist1, semifinalist2)
            Match = New Matches
            Match.year = CInt(comboDate.SelectedItem)
            Match.tournament = AuxTournament.idTournament
            Match.winner = finalist1
            Match.round = CChar("S")
            MatchesCol.Add(Match)

            femPlayer.idPlayer = finalist1
            femPlayer.ReadPlayerByID()

            AdjustPoints(semifinalist1, semifinalist2, Match.round, finalist1)
            fin1TB.Text = femPlayer.PlayerName

            finalist2 = simulatematch(semifinalist3, semifinalist4)
            Match = New Matches
            Match.year = CInt(comboDate.SelectedItem)
            Match.tournament = AuxTournament.idTournament
            Match.winner = finalist2
            Match.round = CChar("S")
            MatchesCol.Add(Match)

            femPlayer.idPlayer = finalist2
            femPlayer.ReadPlayerByID()

            AdjustPoints(semifinalist3, semifinalist4, Match.round, finalist2)
            fin2TB.Text = femPlayer.PlayerName

            winner = simulatematch(finalist1, finalist2)
            Match = New Matches
            Match.year = CInt(comboDate.SelectedItem)
            Match.tournament = AuxTournament.idTournament
            Match.winner = winner
            Match.round = CChar("F")
            MatchesCol.Add(Match)

            femPlayer.idPlayer = winner
            femPlayer.ReadPlayerByID()

            AdjustPoints(finalist1, finalist2, Match.round, winner)
            femPlayer.PlayerPoints += 100
            femPlayer.UpdatePlayer()

            winnerTB.Text = femPlayer.PlayerName
            edition.year = CInt(comboDate.SelectedItem)
            edition.tournament = AuxTournament.idTournament
            edition.winner = winner
            AuxTournament.insertEdition(edition)
            For Each Match In MatchesCol
                Match.InsertMatch()
            Next
            matchts.ReadByTournament(AuxTournament.idTournament, CInt(comboDate.SelectedItem))
            i = 1
            For Each plays In PlaysCol
                Select Case i
                    Case 1, 2
                        matchs = New Matches
                        matchs = CType(matchts.MatchesDAO.Matchs.Item(1), Matches)
                        plays.match = matchs.idMatch
                        femPlayer.InsertPlays(plays)
                    Case 3, 4
                        matchs = CType(matchts.MatchesDAO.Matchs.Item(2), Matches)
                        plays.match = matchs.idMatch
                        femPlayer.InsertPlays(plays)
                    Case 5, 6
                        matchs = CType(matchts.MatchesDAO.Matchs.Item(3), Matches)
                        plays.match = matchs.idMatch
                        femPlayer.InsertPlays(plays)
                    Case 7, 8
                        matchs = CType(matchts.MatchesDAO.Matchs.Item(4), Matches)
                        plays.match = matchs.idMatch
                        femPlayer.InsertPlays(plays)
                    Case 9, 10
                        matchs = CType(matchts.MatchesDAO.Matchs.Item(5), Matches)
                        plays.match = matchs.idMatch
                        femPlayer.InsertPlays(plays)
                    Case 11, 12
                        matchs = CType(matchts.MatchesDAO.Matchs.Item(6), Matches)
                        plays.match = matchs.idMatch
                        femPlayer.InsertPlays(plays)
                    Case 13, 14
                        matchs = CType(matchts.MatchesDAO.Matchs.Item(7), Matches)
                        plays.match = matchs.idMatch
                        femPlayer.InsertPlays(plays)
                End Select
                i += 1
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try

    End Sub

    Private Function simulatematch(p1 As Integer, p2 As Integer) As Integer
        Dim aux, winner1, winner2, winnermatch As Integer
        Dim genRand As New Random
        Dim player1, player2 As New Player
        Dim plays1, plays2 As New RelationPlays
        aux = genRand.Next(1, 2)

        If aux = 1 Then
            plays1.player = p1
            plays1.set1 = 6
            plays2.player = p2
            plays2.set1 = genRand.Next(0, 4)
            winner1 = p1
        Else
            plays1.player = p1
            plays1.set1 = genRand.Next(0, 4)
            plays2.player = p2
            plays2.set1 = 6
            winner1 = p2
        End If
        aux = genRand.Next(1, 2)
        If aux = 1 Then
            plays1.player = p1
            plays1.set2 = 6
            plays2.player = p2
            plays2.set2 = genRand.Next(0, 4)
            winner2 = p1
        Else
            plays1.player = p1
            plays1.set2 = genRand.Next(0, 4)
            plays2.player = p2
            plays2.set2 = 6
            winner2 = p2
        End If
        If winner1 <> winner2 Then
            aux = genRand.Next(1, 2)
            If aux = 1 Then
                plays1.player = p1
                plays1.set3 = 6
                plays2.player = p2
                plays2.set3 = genRand.Next(0, 4)
                winnermatch = p1

            Else
                plays1.player = p1
                plays1.set3 = genRand.Next(0, 4)
                plays2.player = p2
                plays2.set3 = 6
                winnermatch = p2
            End If
        Else
            winnermatch = winner1
        End If
        PlaysCol.Add(plays1)
        PlaysCol.Add(plays2)
        Return winnermatch
    End Function


    Public Sub AdjustPoints(player1 As Integer, player2 As Integer, round As Char, winner As Integer)
        Dim points As Integer
        Dim loser As Player
        Select Case (round)
            Case CChar("QF")
                points = 10
            Case CChar("SF")
                points = 25
            Case CChar("F")
                points = 50

        End Select
        If winner = player1 Then
            loser = New Player
            Try
                loser.idPlayer = player2
                loser.ReadPlayerByID()

                loser.PlayerPoints += points
                loser.UpdatePlayer()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try
        Else
            loser = New Player
            Try
                loser.idPlayer = player1
                loser.ReadPlayerByID()
                loser.PlayerPoints += points
                loser.UpdatePlayer()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ListaAÑOTABLA.Items.Clear()
        ListaIDTABLA.Items.Clear()
        ListaNOMBRETORNEOTABLA.Items.Clear()
        ListaRONDATABLA.Items.Clear()
        ListaWINNERTABLA.Items.Clear()

        If comboDate.SelectedItem IsNot Nothing Then

            Try
                AuxTournament.GenerateChart(CInt(comboDate.SelectedItem))
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try

            Dim aux1, aux2, aux3, aux4 As New Integer
            Dim round As New Char


            For Each aux1 In AuxTournament.TournamentDAO.Matches
                ListaIDTABLA.Items.Add(aux1)
            Next
            For Each aux2 In AuxTournament.TournamentDAO.EditionDates
                ListaAÑOTABLA.Items.Add(aux2)
            Next

            For Each aux3 In AuxTournament.TournamentDAO.Tournaments
                ListaNOMBRETORNEOTABLA.Items.Add(aux3)
            Next

            For Each aux4 In AuxTournament.TournamentDAO.Winners
                ListaWINNERTABLA.Items.Add(aux4)
            Next
            For Each round In AuxTournament.TournamentDAO.Rounds
                ListaRONDATABLA.Items.Add(round)
            Next
        End If
    End Sub


End Class