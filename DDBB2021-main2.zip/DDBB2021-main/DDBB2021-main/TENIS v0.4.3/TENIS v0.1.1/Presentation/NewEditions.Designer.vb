﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class NewEditions
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.comboDate = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TournamentNameTB = New System.Windows.Forms.TextBox()
        Me.genEditionBT = New System.Windows.Forms.Button()
        Me.listPlayers = New System.Windows.Forms.ListBox()
        Me.PlayerTOP4TB = New System.Windows.Forms.TextBox()
        Me.PlayerTOP5TB = New System.Windows.Forms.TextBox()
        Me.PlayerTOP6TB = New System.Windows.Forms.TextBox()
        Me.PlayerTOP3TB = New System.Windows.Forms.TextBox()
        Me.PlayerTOP8TB = New System.Windows.Forms.TextBox()
        Me.PlayerTOP1TB = New System.Windows.Forms.TextBox()
        Me.PlayerTOP2TB = New System.Windows.Forms.TextBox()
        Me.PlayerTOP7TB = New System.Windows.Forms.TextBox()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.PlayersLabel = New System.Windows.Forms.Label()
        Me.scoreLB = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.sem3TB = New System.Windows.Forms.TextBox()
        Me.sem1TB = New System.Windows.Forms.TextBox()
        Me.sem2TB = New System.Windows.Forms.TextBox()
        Me.sem4TB = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.fin1TB = New System.Windows.Forms.TextBox()
        Me.fin2TB = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.winnerTB = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.playBT = New System.Windows.Forms.Button()
        Me.ResetBT = New System.Windows.Forms.Button()
        Me.ReturnBT = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ListaRONDATABLA = New System.Windows.Forms.ListBox()
        Me.ListaWINNERTABLA = New System.Windows.Forms.ListBox()
        Me.ListaNOMBRETORNEOTABLA = New System.Windows.Forms.ListBox()
        Me.ListaAÑOTABLA = New System.Windows.Forms.ListBox()
        Me.ListaIDTABLA = New System.Windows.Forms.ListBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Matchid = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'comboDate
        '
        Me.comboDate.FormattingEnabled = True
        Me.comboDate.Location = New System.Drawing.Point(22, 77)
        Me.comboDate.Name = "comboDate"
        Me.comboDate.Size = New System.Drawing.Size(173, 24)
        Me.comboDate.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(19, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(304, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Select a date for the edition of this tournament:"
        '
        'TournamentNameTB
        '
        Me.TournamentNameTB.Location = New System.Drawing.Point(338, 43)
        Me.TournamentNameTB.Name = "TournamentNameTB"
        Me.TournamentNameTB.Size = New System.Drawing.Size(121, 22)
        Me.TournamentNameTB.TabIndex = 2
        '
        'genEditionBT
        '
        Me.genEditionBT.Location = New System.Drawing.Point(22, 107)
        Me.genEditionBT.Name = "genEditionBT"
        Me.genEditionBT.Size = New System.Drawing.Size(173, 23)
        Me.genEditionBT.TabIndex = 3
        Me.genEditionBT.Text = "GENERATE EDITION"
        Me.genEditionBT.UseVisualStyleBackColor = True
        '
        'listPlayers
        '
        Me.listPlayers.FormattingEnabled = True
        Me.listPlayers.ItemHeight = 16
        Me.listPlayers.Location = New System.Drawing.Point(22, 181)
        Me.listPlayers.Name = "listPlayers"
        Me.listPlayers.Size = New System.Drawing.Size(188, 308)
        Me.listPlayers.TabIndex = 4
        '
        'PlayerTOP4TB
        '
        Me.PlayerTOP4TB.Enabled = False
        Me.PlayerTOP4TB.Location = New System.Drawing.Point(486, 150)
        Me.PlayerTOP4TB.Name = "PlayerTOP4TB"
        Me.PlayerTOP4TB.Size = New System.Drawing.Size(100, 22)
        Me.PlayerTOP4TB.TabIndex = 5
        '
        'PlayerTOP5TB
        '
        Me.PlayerTOP5TB.Enabled = False
        Me.PlayerTOP5TB.Location = New System.Drawing.Point(486, 202)
        Me.PlayerTOP5TB.Name = "PlayerTOP5TB"
        Me.PlayerTOP5TB.Size = New System.Drawing.Size(100, 22)
        Me.PlayerTOP5TB.TabIndex = 6
        '
        'PlayerTOP6TB
        '
        Me.PlayerTOP6TB.Enabled = False
        Me.PlayerTOP6TB.Location = New System.Drawing.Point(486, 273)
        Me.PlayerTOP6TB.Name = "PlayerTOP6TB"
        Me.PlayerTOP6TB.Size = New System.Drawing.Size(100, 22)
        Me.PlayerTOP6TB.TabIndex = 7
        '
        'PlayerTOP3TB
        '
        Me.PlayerTOP3TB.Enabled = False
        Me.PlayerTOP3TB.Location = New System.Drawing.Point(486, 325)
        Me.PlayerTOP3TB.Name = "PlayerTOP3TB"
        Me.PlayerTOP3TB.Size = New System.Drawing.Size(100, 22)
        Me.PlayerTOP3TB.TabIndex = 8
        '
        'PlayerTOP8TB
        '
        Me.PlayerTOP8TB.Enabled = False
        Me.PlayerTOP8TB.Location = New System.Drawing.Point(486, 99)
        Me.PlayerTOP8TB.Name = "PlayerTOP8TB"
        Me.PlayerTOP8TB.Size = New System.Drawing.Size(100, 22)
        Me.PlayerTOP8TB.TabIndex = 12
        '
        'PlayerTOP1TB
        '
        Me.PlayerTOP1TB.Enabled = False
        Me.PlayerTOP1TB.Location = New System.Drawing.Point(486, 54)
        Me.PlayerTOP1TB.Name = "PlayerTOP1TB"
        Me.PlayerTOP1TB.Size = New System.Drawing.Size(100, 22)
        Me.PlayerTOP1TB.TabIndex = 11
        '
        'PlayerTOP2TB
        '
        Me.PlayerTOP2TB.Enabled = False
        Me.PlayerTOP2TB.Location = New System.Drawing.Point(486, 425)
        Me.PlayerTOP2TB.Name = "PlayerTOP2TB"
        Me.PlayerTOP2TB.Size = New System.Drawing.Size(100, 22)
        Me.PlayerTOP2TB.TabIndex = 10
        '
        'PlayerTOP7TB
        '
        Me.PlayerTOP7TB.Enabled = False
        Me.PlayerTOP7TB.Location = New System.Drawing.Point(486, 374)
        Me.PlayerTOP7TB.Name = "PlayerTOP7TB"
        Me.PlayerTOP7TB.Size = New System.Drawing.Size(100, 22)
        Me.PlayerTOP7TB.TabIndex = 9
        '
        'PlayersLabel
        '
        Me.PlayersLabel.AutoSize = True
        Me.PlayersLabel.Location = New System.Drawing.Point(19, 151)
        Me.PlayersLabel.Name = "PlayersLabel"
        Me.PlayersLabel.Size = New System.Drawing.Size(109, 17)
        Me.PlayersLabel.TabIndex = 14
        Me.PlayersLabel.Text = "Chart of Players"
        '
        'scoreLB
        '
        Me.scoreLB.AutoSize = True
        Me.scoreLB.Location = New System.Drawing.Point(237, 181)
        Me.scoreLB.Name = "scoreLB"
        Me.scoreLB.Size = New System.Drawing.Size(53, 17)
        Me.scoreLB.TabIndex = 15
        Me.scoreLB.Text = "Score :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(603, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(143, 17)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "---------------------------"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(735, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(11, 17)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "|"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(603, 104)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(143, 17)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "---------------------------"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(735, 97)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(11, 17)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "|"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(735, 80)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(11, 17)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "|"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(752, 181)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 17)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "---------"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(735, 181)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(11, 17)
        Me.Label9.TabIndex = 26
        Me.Label9.Text = "|"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(735, 198)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(11, 17)
        Me.Label10.TabIndex = 25
        Me.Label10.Text = "|"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(603, 205)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(143, 17)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "---------------------------"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(735, 160)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(11, 17)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "|"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(603, 155)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(143, 17)
        Me.Label13.TabIndex = 22
        Me.Label13.Text = "---------------------------"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(735, 302)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(11, 17)
        Me.Label15.TabIndex = 32
        Me.Label15.Text = "|"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(735, 319)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(11, 17)
        Me.Label16.TabIndex = 31
        Me.Label16.Text = "|"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(603, 326)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(143, 17)
        Me.Label17.TabIndex = 30
        Me.Label17.Text = "---------------------------"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(735, 281)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(11, 17)
        Me.Label18.TabIndex = 29
        Me.Label18.Text = "|"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(603, 276)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(143, 17)
        Me.Label19.TabIndex = 28
        Me.Label19.Text = "---------------------------"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(735, 403)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(11, 17)
        Me.Label21.TabIndex = 38
        Me.Label21.Text = "|"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(735, 420)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(11, 17)
        Me.Label22.TabIndex = 37
        Me.Label22.Text = "|"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(603, 427)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(143, 17)
        Me.Label23.TabIndex = 36
        Me.Label23.Text = "---------------------------"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(735, 382)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(11, 17)
        Me.Label24.TabIndex = 35
        Me.Label24.Text = "|"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(603, 377)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(143, 17)
        Me.Label25.TabIndex = 34
        Me.Label25.Text = "---------------------------"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(752, 302)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(53, 17)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "---------"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(752, 80)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(53, 17)
        Me.Label14.TabIndex = 40
        Me.Label14.Text = "---------"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(752, 403)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(53, 17)
        Me.Label20.TabIndex = 41
        Me.Label20.Text = "---------"
        '
        'sem3TB
        '
        Me.sem3TB.Enabled = False
        Me.sem3TB.Location = New System.Drawing.Point(811, 302)
        Me.sem3TB.Name = "sem3TB"
        Me.sem3TB.Size = New System.Drawing.Size(100, 22)
        Me.sem3TB.TabIndex = 42
        '
        'sem1TB
        '
        Me.sem1TB.Enabled = False
        Me.sem1TB.Location = New System.Drawing.Point(812, 80)
        Me.sem1TB.Name = "sem1TB"
        Me.sem1TB.Size = New System.Drawing.Size(100, 22)
        Me.sem1TB.TabIndex = 43
        '
        'sem2TB
        '
        Me.sem2TB.Enabled = False
        Me.sem2TB.Location = New System.Drawing.Point(811, 181)
        Me.sem2TB.Name = "sem2TB"
        Me.sem2TB.Size = New System.Drawing.Size(100, 22)
        Me.sem2TB.TabIndex = 44
        '
        'sem4TB
        '
        Me.sem4TB.Enabled = False
        Me.sem4TB.Location = New System.Drawing.Point(811, 398)
        Me.sem4TB.Name = "sem4TB"
        Me.sem4TB.Size = New System.Drawing.Size(100, 22)
        Me.sem4TB.TabIndex = 45
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(1066, 357)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(53, 17)
        Me.Label26.TabIndex = 51
        Me.Label26.Text = "---------"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(1049, 331)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(11, 17)
        Me.Label27.TabIndex = 50
        Me.Label27.Text = "|"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(1049, 396)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(11, 17)
        Me.Label28.TabIndex = 49
        Me.Label28.Text = "|"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(917, 403)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(143, 17)
        Me.Label29.TabIndex = 48
        Me.Label29.Text = "---------------------------"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(1049, 310)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(11, 17)
        Me.Label30.TabIndex = 47
        Me.Label30.Text = "|"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(917, 305)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(143, 17)
        Me.Label31.TabIndex = 46
        Me.Label31.Text = "---------------------------"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(1049, 348)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(11, 17)
        Me.Label32.TabIndex = 52
        Me.Label32.Text = "|"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(1049, 374)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(11, 17)
        Me.Label33.TabIndex = 53
        Me.Label33.Text = "|"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(1049, 152)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(11, 17)
        Me.Label34.TabIndex = 61
        Me.Label34.Text = "|"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(1049, 126)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(11, 17)
        Me.Label35.TabIndex = 60
        Me.Label35.Text = "|"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(1066, 135)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(53, 17)
        Me.Label36.TabIndex = 59
        Me.Label36.Text = "---------"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(1049, 109)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(11, 17)
        Me.Label37.TabIndex = 58
        Me.Label37.Text = "|"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(1049, 174)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(11, 17)
        Me.Label38.TabIndex = 57
        Me.Label38.Text = "|"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(917, 181)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(143, 17)
        Me.Label39.TabIndex = 56
        Me.Label39.Text = "---------------------------"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(1049, 88)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(11, 17)
        Me.Label40.TabIndex = 55
        Me.Label40.Text = "|"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(917, 83)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(143, 17)
        Me.Label41.TabIndex = 54
        Me.Label41.Text = "---------------------------"
        '
        'fin1TB
        '
        Me.fin1TB.Enabled = False
        Me.fin1TB.Location = New System.Drawing.Point(1125, 130)
        Me.fin1TB.Name = "fin1TB"
        Me.fin1TB.Size = New System.Drawing.Size(100, 22)
        Me.fin1TB.TabIndex = 62
        '
        'fin2TB
        '
        Me.fin2TB.Enabled = False
        Me.fin2TB.Location = New System.Drawing.Point(1125, 357)
        Me.fin2TB.Name = "fin2TB"
        Me.fin2TB.Size = New System.Drawing.Size(100, 22)
        Me.fin2TB.TabIndex = 63
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(1363, 331)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(11, 17)
        Me.Label42.TabIndex = 71
        Me.Label42.Text = "|"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(1363, 178)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(11, 17)
        Me.Label43.TabIndex = 70
        Me.Label43.Text = "|"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(1380, 241)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(53, 17)
        Me.Label44.TabIndex = 69
        Me.Label44.Text = "---------"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(1363, 161)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(11, 17)
        Me.Label45.TabIndex = 68
        Me.Label45.Text = "|"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(1363, 353)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(11, 17)
        Me.Label46.TabIndex = 67
        Me.Label46.Text = "|"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(1231, 360)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(143, 17)
        Me.Label47.TabIndex = 66
        Me.Label47.Text = "---------------------------"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(1363, 140)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(11, 17)
        Me.Label48.TabIndex = 65
        Me.Label48.Text = "|"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(1231, 135)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(143, 17)
        Me.Label49.TabIndex = 64
        Me.Label49.Text = "---------------------------"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(1363, 224)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(11, 17)
        Me.Label50.TabIndex = 73
        Me.Label50.Text = "|"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(1363, 207)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(11, 17)
        Me.Label51.TabIndex = 72
        Me.Label51.Text = "|"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(1363, 258)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(11, 17)
        Me.Label52.TabIndex = 75
        Me.Label52.Text = "|"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(1363, 241)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(11, 17)
        Me.Label53.TabIndex = 74
        Me.Label53.Text = "|"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(1363, 298)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(11, 17)
        Me.Label54.TabIndex = 77
        Me.Label54.Text = "|"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(1363, 281)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(11, 17)
        Me.Label55.TabIndex = 76
        Me.Label55.Text = "|"
        '
        'winnerTB
        '
        Me.winnerTB.Enabled = False
        Me.winnerTB.Location = New System.Drawing.Point(1439, 241)
        Me.winnerTB.Name = "winnerTB"
        Me.winnerTB.Size = New System.Drawing.Size(100, 22)
        Me.winnerTB.TabIndex = 78
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(505, 9)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(127, 17)
        Me.Label56.TabIndex = 79
        Me.Label56.Text = "QUARTER FINALS"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(808, 9)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(92, 17)
        Me.Label57.TabIndex = 80
        Me.Label57.Text = "SEMI-FINALS"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(1141, 9)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(55, 17)
        Me.Label58.TabIndex = 81
        Me.Label58.Text = "FINALS"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(1436, 9)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(66, 17)
        Me.Label59.TabIndex = 82
        Me.Label59.Text = "WINNER!"
        '
        'playBT
        '
        Me.playBT.Enabled = False
        Me.playBT.Location = New System.Drawing.Point(354, 230)
        Me.playBT.Name = "playBT"
        Me.playBT.Size = New System.Drawing.Size(103, 45)
        Me.playBT.TabIndex = 83
        Me.playBT.Text = "PLAY!"
        Me.playBT.UseVisualStyleBackColor = True
        '
        'ResetBT
        '
        Me.ResetBT.Location = New System.Drawing.Point(224, 109)
        Me.ResetBT.Name = "ResetBT"
        Me.ResetBT.Size = New System.Drawing.Size(75, 23)
        Me.ResetBT.TabIndex = 84
        Me.ResetBT.Text = "Reset"
        Me.ResetBT.UseVisualStyleBackColor = True
        '
        'ReturnBT
        '
        Me.ReturnBT.Location = New System.Drawing.Point(22, 12)
        Me.ReturnBT.Name = "ReturnBT"
        Me.ReturnBT.Size = New System.Drawing.Size(35, 23)
        Me.ReturnBT.TabIndex = 85
        Me.ReturnBT.Text = "←"
        Me.ReturnBT.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ListaRONDATABLA)
        Me.GroupBox1.Controls.Add(Me.ListaWINNERTABLA)
        Me.GroupBox1.Controls.Add(Me.ListaNOMBRETORNEOTABLA)
        Me.GroupBox1.Controls.Add(Me.ListaAÑOTABLA)
        Me.GroupBox1.Controls.Add(Me.ListaIDTABLA)
        Me.GroupBox1.Controls.Add(Me.Label62)
        Me.GroupBox1.Controls.Add(Me.Label63)
        Me.GroupBox1.Controls.Add(Me.Label64)
        Me.GroupBox1.Controls.Add(Me.Matchid)
        Me.GroupBox1.Controls.Add(Me.Label61)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 554)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(596, 263)
        Me.GroupBox1.TabIndex = 86
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Match Chart"
        '
        'ListaRONDATABLA
        '
        Me.ListaRONDATABLA.FormattingEnabled = True
        Me.ListaRONDATABLA.ItemHeight = 16
        Me.ListaRONDATABLA.Location = New System.Drawing.Point(449, 66)
        Me.ListaRONDATABLA.Name = "ListaRONDATABLA"
        Me.ListaRONDATABLA.Size = New System.Drawing.Size(47, 180)
        Me.ListaRONDATABLA.TabIndex = 94
        '
        'ListaWINNERTABLA
        '
        Me.ListaWINNERTABLA.FormattingEnabled = True
        Me.ListaWINNERTABLA.ItemHeight = 16
        Me.ListaWINNERTABLA.Location = New System.Drawing.Point(376, 66)
        Me.ListaWINNERTABLA.Name = "ListaWINNERTABLA"
        Me.ListaWINNERTABLA.Size = New System.Drawing.Size(55, 180)
        Me.ListaWINNERTABLA.TabIndex = 93
        '
        'ListaNOMBRETORNEOTABLA
        '
        Me.ListaNOMBRETORNEOTABLA.FormattingEnabled = True
        Me.ListaNOMBRETORNEOTABLA.ItemHeight = 16
        Me.ListaNOMBRETORNEOTABLA.Location = New System.Drawing.Point(245, 66)
        Me.ListaNOMBRETORNEOTABLA.Name = "ListaNOMBRETORNEOTABLA"
        Me.ListaNOMBRETORNEOTABLA.Size = New System.Drawing.Size(113, 180)
        Me.ListaNOMBRETORNEOTABLA.TabIndex = 92
        '
        'ListaAÑOTABLA
        '
        Me.ListaAÑOTABLA.FormattingEnabled = True
        Me.ListaAÑOTABLA.ItemHeight = 16
        Me.ListaAÑOTABLA.Location = New System.Drawing.Point(142, 70)
        Me.ListaAÑOTABLA.Name = "ListaAÑOTABLA"
        Me.ListaAÑOTABLA.Size = New System.Drawing.Size(63, 180)
        Me.ListaAÑOTABLA.TabIndex = 89
        '
        'ListaIDTABLA
        '
        Me.ListaIDTABLA.FormattingEnabled = True
        Me.ListaIDTABLA.ItemHeight = 16
        Me.ListaIDTABLA.Location = New System.Drawing.Point(17, 72)
        Me.ListaIDTABLA.Name = "ListaIDTABLA"
        Me.ListaIDTABLA.Size = New System.Drawing.Size(66, 180)
        Me.ListaIDTABLA.TabIndex = 88
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(446, 34)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(50, 17)
        Me.Label62.TabIndex = 89
        Me.Label62.Text = "Round"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(365, 34)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(70, 17)
        Me.Label63.TabIndex = 90
        Me.Label63.Text = "Winner ID"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(242, 34)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(102, 17)
        Me.Label64.TabIndex = 91
        Me.Label64.Text = "Tournament ID"
        '
        'Matchid
        '
        Me.Matchid.AutoSize = True
        Me.Matchid.Location = New System.Drawing.Point(14, 34)
        Me.Matchid.Name = "Matchid"
        Me.Matchid.Size = New System.Drawing.Size(63, 17)
        Me.Matchid.TabIndex = 1
        Me.Matchid.Text = "Match ID"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(139, 34)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(83, 17)
        Me.Label61.TabIndex = 88
        Me.Label61.Text = "Edition year"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(335, 298)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(59, 17)
        Me.Label60.TabIndex = 87
        Me.Label60.Text = "Label60"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(24, 525)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(171, 23)
        Me.Button1.TabIndex = 88
        Me.Button1.Text = "GENERATE CHART"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'NewEditions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1656, 829)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label60)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ReturnBT)
        Me.Controls.Add(Me.ResetBT)
        Me.Controls.Add(Me.playBT)
        Me.Controls.Add(Me.Label59)
        Me.Controls.Add(Me.Label58)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.winnerTB)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.Label51)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.Label48)
        Me.Controls.Add(Me.Label49)
        Me.Controls.Add(Me.fin2TB)
        Me.Controls.Add(Me.fin1TB)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.sem4TB)
        Me.Controls.Add(Me.sem2TB)
        Me.Controls.Add(Me.sem1TB)
        Me.Controls.Add(Me.sem3TB)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.scoreLB)
        Me.Controls.Add(Me.PlayersLabel)
        Me.Controls.Add(Me.PlayerTOP8TB)
        Me.Controls.Add(Me.PlayerTOP1TB)
        Me.Controls.Add(Me.PlayerTOP2TB)
        Me.Controls.Add(Me.PlayerTOP7TB)
        Me.Controls.Add(Me.PlayerTOP3TB)
        Me.Controls.Add(Me.PlayerTOP6TB)
        Me.Controls.Add(Me.PlayerTOP5TB)
        Me.Controls.Add(Me.PlayerTOP4TB)
        Me.Controls.Add(Me.listPlayers)
        Me.Controls.Add(Me.genEditionBT)
        Me.Controls.Add(Me.TournamentNameTB)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.comboDate)
        Me.Name = "NewEditions"
        Me.Text = "NewEditions"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents comboDate As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TournamentNameTB As TextBox
    Friend WithEvents genEditionBT As Button
    Friend WithEvents listPlayers As ListBox
    Friend WithEvents PlayerTOP4TB As TextBox
    Friend WithEvents PlayerTOP5TB As TextBox
    Friend WithEvents PlayerTOP6TB As TextBox
    Friend WithEvents PlayerTOP3TB As TextBox
    Friend WithEvents PlayerTOP8TB As TextBox
    Friend WithEvents PlayerTOP1TB As TextBox
    Friend WithEvents PlayerTOP2TB As TextBox
    Friend WithEvents PlayerTOP7TB As TextBox
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents PlayersLabel As Label
    Friend WithEvents scoreLB As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents sem3TB As TextBox
    Friend WithEvents sem1TB As TextBox
    Friend WithEvents sem2TB As TextBox
    Friend WithEvents sem4TB As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents fin1TB As TextBox
    Friend WithEvents fin2TB As TextBox
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents winnerTB As TextBox
    Friend WithEvents Label56 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents playBT As Button
    Friend WithEvents ResetBT As Button
    Friend WithEvents ReturnBT As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Matchid As Label
    Friend WithEvents ListaRONDATABLA As ListBox
    Friend WithEvents ListaWINNERTABLA As ListBox
    Friend WithEvents ListaNOMBRETORNEOTABLA As ListBox
    Friend WithEvents ListaAÑOTABLA As ListBox
    Friend WithEvents ListaIDTABLA As ListBox
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Button1 As Button
End Class
