﻿Public Class Main_Interface

    Private FemPlayer As Player
    Private Tournament As Tournaments
    Private PlCountry As Country


    Private Sub ConnectionB_Click(sender As Object, e As EventArgs) Handles ConnectionB.Click

        FemPlayer = New Player()
        Try
            FemPlayer.ReadAllPlayers()
            MessageBox.Show("Action Completed")
            playerB.Enabled = True
            countryB.Enabled = True
            tournamentB.Enabled = True
        Catch ex As Exception
            MessageBox.Show("Could not connect to database. Error Type : " + ex.Message + "Error Source : " + ex.Source)
        End Try

        ConnectionB.Enabled = False


    End Sub

    Private Sub playerB_Click(sender As Object, e As EventArgs) Handles playerB.Click
        Dim femPlayers = New femPlayers()
        femPlayers.Activate()
        femPlayers.Show()
        Me.Hide()
    End Sub

    Private Sub countryB_Click(sender As Object, e As EventArgs) Handles countryB.Click
        Dim countriesframe = New Countries()
        countriesframe.Activate()
        countriesframe.Show()
        Me.Hide()
    End Sub

    Private Sub tournamentB_Click(sender As Object, e As EventArgs) Handles tournamentB.Click
        Dim tournframe = New Tournaments()
        tournframe.Activate()
        tournframe.Show()
        Me.Hide()
    End Sub

    Private Sub Main_Interface_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
