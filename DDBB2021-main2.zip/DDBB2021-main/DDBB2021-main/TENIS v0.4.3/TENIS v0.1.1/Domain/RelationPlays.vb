﻿Public Class RelationPlays

    Property player As Integer
    Property match As Integer
    Property set1 As Integer
    Property set2 As Integer
    Property set3 As Integer

End Class
