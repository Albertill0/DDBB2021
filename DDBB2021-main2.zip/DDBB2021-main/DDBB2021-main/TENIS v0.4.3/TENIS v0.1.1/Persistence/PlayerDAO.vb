﻿Public Class PlayerDAO

    Public ReadOnly Property Players As Collection

    Public ReadOnly Property Rounds As Collection
    Public ReadOnly Property TNames As Collection
    Public ReadOnly Property Nwins As Collection
    Public ReadOnly Property NFinals As Collection
    Public ReadOnly Property PlayerPoints As Collection
    Public ReadOnly Property PNames As Collection



    Public Sub New()
        Me.Players = New Collection
        Me.Rounds = New Collection
        Me.TNames = New Collection
        Me.Nwins = New Collection
        Me.NFinals = New Collection
        Me.PlayerPoints = New Collection
        Me.PNames = New Collection
    End Sub

    Public Sub ReadAll()
        Dim p As Player
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT * FROM Players ORDER BY idPlayer")
        For Each aux In col
            p = New Player(CInt(aux(1).ToString))
            p.PlayerName = aux(2).ToString
            p.PlayerBirthdate = CDate(aux(3).ToString)
            p.PlayerPoints = CInt(aux(4).ToString)
            p.PlayerCountry = aux(5).ToString
            Me.Players.Add(p)
        Next
    End Sub

    Friend Sub ReadByName(ByRef p As Player)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Players WHERE PlayerName='" & p.PlayerName & "';")
        For Each aux In col
            p.idPlayer = CInt(aux(1).ToString)
            p.PlayerBirthdate = CDate(aux(3).ToString)
            p.PlayerPoints = CInt(aux(4).ToString)
            p.PlayerCountry = aux(5).ToString
        Next
    End Sub

    Public Sub ReadByID(ByRef p As Player)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Players WHERE idPlayer='" & p.idPlayer & "';")
        For Each aux In col
            p.PlayerName = aux(2).ToString
            p.PlayerBirthdate = CDate(aux(3).ToString)
            p.PlayerPoints = CInt(aux(4).ToString)
            p.PlayerCountry = aux(5).ToString
        Next
    End Sub

    Public Sub showResultbydate(player As Player, dateSelected As Integer)
        Dim col, aux As Collection
        col = DBBroker.GetBroker.Read("SELECT m.round, t.TournamentName FROM Matches m, Tournaments t, Players p WHERE m.tournament = t.idTournament AND 
	     m.winner ='" & player.idPlayer & "' AND m.year ='" & dateSelected & "' AND p.PlayerName ='" & player.PlayerName & "';")
        For Each aux In col
            Me.Rounds.Add(aux(1).ToString)
            Me.TNames.Add(aux(2).ToString)
        Next
    End Sub
    Public Sub showRanking()
        Dim p As New Player
        Dim col, aux As Collection
        col = DBBroker.GetBroker.Read("SELECT p.PlayerName, p.IdPlayer, p.PlayerPoints FROM Players p GROUP BY(p.idPlayer) ORDER BY(p.PlayerPoints) DESC;")
        For Each aux In col
            Me.PNames.Add(aux(1).ToString)
            Me.PlayerPoints.Add(aux(3).ToString)
            p.idPlayer = CInt(aux(2).ToString)
            Me.Players.Add(p)
        Next
    End Sub
    Public Sub CountWins(playerId As Integer)
        Dim col, aux As Collection
        col = DBBroker.GetBroker.Read("SELECT COUNT(e.winner) FROM Editions e WHERE e.winner = '" & playerId & "';")
        For Each aux In col
            Me.Nwins.Add(aux(1).ToString)
        Next
    End Sub
    Public Sub CountFinals(playerId As Integer)
        Dim col, aux As Collection
        col = DBBroker.GetBroker.Read("SELECT COUNT(m.round) FROM Plays p, Matches m WHERE p.player = '" & playerId & "' AND m.matchId = p.match AND m.round = 'F';")
        For Each aux In col
            Me.Nwins.Add(aux(1).ToString)
        Next
    End Sub

    Public Function InsertPlays(plays As RelationPlays) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Plays VALUES ('" & plays.player & "', '" & plays.match & "', '" & plays.set1 & "', '" & plays.set2 & "', '" & plays.set3 & "');")
    End Function

    Public Sub ReadRandom()
        Dim col As Collection : Dim aux As Collection : Dim p As Player
        col = DBBroker.GetBroker.Read("SELECT * FROM (SELECT * FROM Players ORDER BY RAND() LIMIT 8) AS alias ORDER BY PlayerPoints DESC;")
        For Each aux In col
            p = New Player(CInt(aux(1).ToString)) With {
                .PlayerName = aux(2).ToString,
                .PlayerBirthdate = CDate(aux(3).ToString),
                .PlayerPoints = CInt(aux(4).ToString),
                .PlayerCountry = aux(5).ToString
            }
            Me.Players.Add(p)
        Next
    End Sub

    Public Function Insert(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Players (PlayerName,PlayerBirthdate,PlayerPoints,PlayerCountry) VALUES ('" & p.PlayerName & "', '" & p.PlayerBirthdate.ToString("yyyy/MM/dd") & "', '" & p.PlayerPoints & "', '" & p.PlayerCountry & "');")
    End Function

    Public Function Update(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("UPDATE Players SET PlayerName='" & p.PlayerName & "', PlayerBirthdate= '" & p.PlayerBirthdate.ToString("yyyy/MM/dd") & "', PlayerPoints= '" & p.PlayerPoints & "', PlayerCountry= '" & p.PlayerCountry & "' WHERE idPlayer='" & p.idPlayer & "';")
    End Function

    Public Function Delete(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("DELETE FROM Players WHERE idPlayer='" & p.idPlayer & "';")
    End Function
    Public Function DeleteByName(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("DELETE FROM Players WHERE PlayerName='" & p.PlayerName & "';")
    End Function

End Class
