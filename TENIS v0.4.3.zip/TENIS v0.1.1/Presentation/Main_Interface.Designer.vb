﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main_Interface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ConnectionB = New System.Windows.Forms.Button()
        Me.tournamentB = New System.Windows.Forms.Button()
        Me.playerB = New System.Windows.Forms.Button()
        Me.countryB = New System.Windows.Forms.Button()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ConnectionB
        '
        Me.ConnectionB.Location = New System.Drawing.Point(294, 236)
        Me.ConnectionB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ConnectionB.Name = "ConnectionB"
        Me.ConnectionB.Size = New System.Drawing.Size(186, 38)
        Me.ConnectionB.TabIndex = 0
        Me.ConnectionB.Text = "Connect to database"
        Me.ConnectionB.UseVisualStyleBackColor = True
        '
        'tournamentB
        '
        Me.tournamentB.AllowDrop = True
        Me.tournamentB.Enabled = False
        Me.tournamentB.Location = New System.Drawing.Point(481, 133)
        Me.tournamentB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tournamentB.Name = "tournamentB"
        Me.tournamentB.Size = New System.Drawing.Size(186, 45)
        Me.tournamentB.TabIndex = 1
        Me.tournamentB.Text = "Tournaments"
        Me.tournamentB.UseVisualStyleBackColor = True
        '
        'playerB
        '
        Me.playerB.Enabled = False
        Me.playerB.Location = New System.Drawing.Point(294, 50)
        Me.playerB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.playerB.Name = "playerB"
        Me.playerB.Size = New System.Drawing.Size(186, 43)
        Me.playerB.TabIndex = 2
        Me.playerB.Text = "Players"
        Me.playerB.UseVisualStyleBackColor = True
        '
        'countryB
        '
        Me.countryB.Enabled = False
        Me.countryB.Location = New System.Drawing.Point(107, 133)
        Me.countryB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.countryB.Name = "countryB"
        Me.countryB.Size = New System.Drawing.Size(186, 45)
        Me.countryB.TabIndex = 3
        Me.countryB.Text = "Countries"
        Me.countryB.UseVisualStyleBackColor = True
        '
        'Main_Interface
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 360)
        Me.Controls.Add(Me.countryB)
        Me.Controls.Add(Me.playerB)
        Me.Controls.Add(Me.tournamentB)
        Me.Controls.Add(Me.ConnectionB)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Main_Interface"
        Me.Text = "Form1"
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ConnectionB As Button
    Friend WithEvents tournamentB As Button
    Friend WithEvents playerB As Button
    Friend WithEvents countryB As Button
    Friend WithEvents BindingSource1 As BindingSource
End Class
