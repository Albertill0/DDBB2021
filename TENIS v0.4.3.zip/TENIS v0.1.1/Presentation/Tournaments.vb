﻿Public Class Tournaments
    Public tournament As Tournament
    Private AuxCountry As Country
    Private Sub Tournaments_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aux As Tournament
        tournament = New Tournament()
        Try
            tournament.ReadAllTournaments()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        For Each aux In tournament.TournamentDAO.Tournaments
            listaID.Items.Add(aux.TournamentName)
        Next
        listaID.Refresh()
        NewEdBT.Enabled = False
        UpdateBT.Enabled = False
        DeleteBT.Enabled = False
        InsertBT.Enabled = True
        listEdDates.Enabled = False
        WinnersList.Enabled = False
        ClearBT.Enabled = True
        Dim auxc As Country
        AuxCountry = New Country()
        Try
            AuxCountry.ReadAllCountries()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        For Each auxc In AuxCountry.CountriesDAO.Countries_coll
            ComboCountry.Items.Add(auxc.CountryName)
        Next
    End Sub

    Private Sub MenuBT_Click(sender As Object, e As EventArgs) Handles MenuBT.Click
        Dim Main As New Main_Interface()
        Main.Activate()
        Main.ConnectionB.Enabled = False
        Main.playerB.Enabled = True
        Main.countryB.Enabled = True
        Main.tournamentB.Enabled = True
        Main.Show()
        Me.Hide()
    End Sub

    Private Sub listaID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaID.SelectedIndexChanged
        listEdDates.Items.Clear()
        WinnersList.Items.Clear()
        If listaID.SelectedItem IsNot Nothing Or listaID.SelectedItem IsNot "" Then
            NewEdBT.Enabled = True
            AuxCountry = New Country

            tournament = New Tournament With {
                .TournamentName = listaID.SelectedItem
            }

            Try
                tournament.ReadTournamentByName()
                tournament.ReadWinners()
                AuxCountry.idCountry = tournament.TournamentCountry
                AuxCountry.ReadCountry()
                NameTB.Text = tournament.TournamentName
                CityTB.Text = tournament.TournamentCity
                ComboCountry.Text = AuxCountry.CountryName
                UpdateBT.Enabled = True
                DeleteBT.Enabled = True

            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try
            Dim aux As Integer
            Dim aux2 As String
            For Each aux In tournament.TournamentDAO.EditionDates
                listEdDates.Items.Add(aux)
            Next
            For Each aux2 In tournament.TournamentDAO.Players
                WinnersList.Items.Add(aux2)
            Next

        End If

    End Sub

    Private Sub InsertBT_Click(sender As Object, e As EventArgs) Handles InsertBT.Click
        If CityTB.Text IsNot "" Or NameTB.Text IsNot "" Or ComboCountry.Text IsNot Nothing Then

            AuxCountry = New Country With {
            .CountryName = ComboCountry.Text
        }


            tournament = New Tournament With {
            .TournamentName = NameTB.Text,
            .TournamentCity = CityTB.Text
        }
            Try
                AuxCountry.ReadCountryByName()
                tournament.TournamentCountry = AuxCountry.CountryName
                tournament.InsertTournament()
                listaID.Items.Clear()
                Tournaments_Load(sender, e)
                listaID.Refresh()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try
        End If


    End Sub

    Private Sub ClearBT_Click(sender As Object, e As EventArgs) Handles ClearBT.Click
        UpdateBT.Enabled = False
        DeleteBT.Enabled = False
        NameTB.Text = ""
        ComboCountry.Text = ""
        CityTB.Text = ""
        InsertBT.Enabled = True
    End Sub

    Private Sub UpdateBT_Click(sender As Object, e As EventArgs) Handles UpdateBT.Click
        If CityTB.Text IsNot "" Or NameTB.Text IsNot "" Or ComboCountry.Text IsNot Nothing Then
            AuxCountry = New Country With {
                .CountryName = ComboCountry.Text
            }

            tournament = New Tournament With {
            .TournamentName = listaID.SelectedItem
        }

            Try
                AuxCountry.ReadCountryByName()
                tournament.ReadTournamentByName()
                tournament.TournamentName = NameTB.Text
                tournament.TournamentCity = CityTB.Text
                tournament.TournamentCountry = AuxCountry.idCountry
                tournament.UpdateTournament()
                MessageBox.Show("Updated tournament properly")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try
        End If
    End Sub

    Private Sub DeleteBT_Click(sender As Object, e As EventArgs) Handles DeleteBT.Click
        tournament = New Tournament With {
            .TournamentName = listaID.SelectedItem
        }

        Try
            tournament.ReadTournamentByName()
            tournament.DeleteTournament()
            MessageBox.Show("Deleted country properly")
            listaID.Items.Remove(listaID.SelectedItem)
            listaID.Refresh()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
    End Sub

    Private Sub NewEdBT_Click(sender As Object, e As EventArgs) Handles NewEdBT.Click
        Dim answer As Integer

        answer = MsgBox("Do you really want to create a new edition for the tournament already selected?", vbQuestion + vbYesNo + vbDefaultButton2, "Create New Edition to play?")
        If answer = vbYes Then
            Dim NewEditionsFrm As New NewEditions(Me)
            NewEditionsFrm.Activate()
            NewEditionsFrm.Show()
            Me.Hide()
        End If
    End Sub


End Class