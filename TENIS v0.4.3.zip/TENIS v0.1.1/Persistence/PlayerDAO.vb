﻿Public Class PlayerDAO

    Public ReadOnly Property Players As Collection

    Public ReadOnly Property Rounds As Collection
    Public ReadOnly Property TNames As Collection


    Public Sub New()
        Me.Players = New Collection
        Me.Rounds = New Collection
        Me.TNames = New Collection
    End Sub

    Public Sub ReadAll()
        Dim p As Player
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT * FROM Players ORDER BY idPlayer")
        For Each aux In col
            p = New Player(aux(1).ToString)
            p.PlayerName = aux(2).ToString
            p.PlayerBirthdate = aux(3).ToString
            p.PlayerPoints = aux(4).ToString
            p.PlayerCountry = aux(5).ToString
            Me.Players.Add(p)
        Next
    End Sub

    Friend Sub ReadByName(ByRef p As Player)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Players WHERE PlayerName='" & p.PlayerName & "';")
        For Each aux In col
            p.idPlayer = aux(1).ToString
            p.PlayerBirthdate = aux(3).ToString
            p.PlayerPoints = aux(4).ToString
            p.PlayerCountry = aux(5).ToString
        Next
    End Sub

    Public Sub ReadByID(ByRef p As Player)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Players WHERE idPlayer='" & p.idPlayer & "';")
        For Each aux In col
            p.PlayerName = aux(2).ToString
            p.PlayerBirthdate = aux(3).ToString
            p.PlayerPoints = aux(4).ToString
            p.PlayerCountry = aux(5).ToString
        Next
    End Sub

    Public Sub showResultbydate(player As Player, dateSelected As Integer)
        Dim col, aux As Collection
        col = DBBroker.GetBroker.Read("SELECT m.round, t.TournamentName FROM Matches m, Tournaments t, Players p WHERE m.tournament = t.idTournament AND 
	     m.winner ='" & player.idPlayer & "' AND m.year ='" & dateSelected & "' AND p.PlayerName ='" & player.PlayerName & "';")
        For Each aux In col
            Me.Rounds.Add(aux(1).ToString)
            Me.TNames.Add(aux(2).ToString)
        Next
    End Sub

    Public Function InsertPlays(plays As RelationPlays) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Plays VALUES ('" & plays.player & "', '" & plays.match & "', '" & plays.set1 & "', '" & plays.set2 & "', '" & plays.set3 & "');")
    End Function

    Public Sub ReadRandom()
        Dim col As Collection : Dim aux As Collection : Dim p As Player
        col = DBBroker.GetBroker.Read("SELECT * FROM (SELECT * FROM Players ORDER BY RAND() LIMIT 8) AS alias ORDER BY PlayerPoints DESC;")
        For Each aux In col
            p = New Player(aux(1).ToString) With {
                .PlayerName = aux(2).ToString,
                .PlayerBirthdate = aux(3).ToString,
                .PlayerPoints = aux(4).ToString,
                .PlayerCountry = aux(5).ToString
            }
            Me.Players.Add(p)
        Next
    End Sub

    Public Function Insert(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Players (PlayerName,PlayerBirthdate,PlayerPoints,PlayerCountry) VALUES ('" & p.PlayerName & "', '" & p.PlayerBirthdate.ToString("yyyy/MM/dd") & "', '" & p.PlayerPoints & "', '" & p.PlayerCountry & "');")
    End Function

    Public Function Update(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("UPDATE Players SET PlayerName='" & p.PlayerName & "', PlayerBirthdate= '" & p.PlayerBirthdate.ToString("yyyy/MM/dd") & "', PlayerPoints= '" & p.PlayerPoints & "', PlayerCountry= '" & p.PlayerCountry & "' WHERE idPlayer='" & p.idPlayer & "';")
    End Function

    Public Function Delete(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("DELETE FROM Players WHERE idPlayer='" & p.idPlayer & "';")
    End Function
    Public Function DeleteByName(ByVal p As Player) As Integer
        Return DBBroker.GetBroker.Change("DELETE FROM Players WHERE PlayerName='" & p.PlayerName & "';")
    End Function

End Class
