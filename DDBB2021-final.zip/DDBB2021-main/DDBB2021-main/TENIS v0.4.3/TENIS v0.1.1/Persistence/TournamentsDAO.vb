﻿Public Class TournamentsDAO

    Public ReadOnly Property Tournaments As Collection

    Public ReadOnly Property Players As Collection

    Public ReadOnly Property EditionDates As Collection
    Public ReadOnly Property Matches As Collection
    Public ReadOnly Property Winners As Collection
    Public ReadOnly Property Rounds As Collection


    Public Sub New()
        Me.Tournaments = New Collection
        Me.Players = New Collection
        Me.EditionDates = New Collection
        Me.Matches = New Collection
        Me.Winners = New Collection
        Me.Rounds = New Collection

    End Sub

    Public Sub ReadAll()
        Dim t As Tournament
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT * FROM Tournaments ORDER BY idTournament ")
        For Each aux In col
            t = New Tournament(CInt(aux(1).ToString))
            t.tournamentName = aux(2).ToString
            t.TournamentCity = aux(3).ToString
            t.tournamentCountry = aux(4).ToString
            Me.Tournaments.Add(t)
        Next
    End Sub

    Public Sub ReadWinners(tourn As Tournament)
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT p.PlayerName, e.year FROM Players p, Editions e WHERE '" & tourn.idTournament & "' = e.tournament And p.idPlayer = e.winner;")

        For Each aux In col
            Me.Players.Add(aux(1).ToString)
            Me.EditionDates.Add(aux(2).ToString)
        Next

    End Sub

    Public Sub showResults(tournament As Tournament, idPlayer As Integer)
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT m.round, e.year FROM Matches m, Editions e WHERE m.winner = '" & idPlayer & "' AND m.tournament = '" & tournament.idTournament & "' AND e.tournament = 
        '" & tournament.idTournament & "' AND '" & idPlayer & "' = e.winner;")

        For Each aux In col
            Me.Rounds.Add(aux(1).ToString)
            Me.EditionDates.Add(aux(2).ToString)
        Next

    End Sub

    Public Sub GenerateChart(tournament As Tournament, dateselected As Integer)
        Dim col, aux As Collection
        col = DBBroker.GetBroker().Read("SELECT * FROM Matches m WHERE '" & tournament.idTournament & "' = m.tournament AND '" & dateselected & "' = m.year;")

        For Each aux In col
            Me.Matches.Add(aux(1).ToString)
            Me.EditionDates.Add(aux(2).ToString)
            Me.Tournaments.Add(aux(3).ToString)
            Me.Winners.Add(aux(4).ToString)
            Me.Rounds.Add(aux(5).ToString)
        Next

    End Sub

    Public Sub Read(ByRef t As Tournament)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Tournaments WHERE idTournament='" & t.idTournament & "';")
        For Each aux In col
            t.TournamentName = aux(2).ToString
            t.TournamentCity = aux(3).ToString
            t.TournamentCountry = aux(4).ToString
        Next
    End Sub

    Public Function Insert(ByVal t As Tournament) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Tournaments VALUES ('" & t.idTournament & "','" & t.TournamentName & "', '" & t.TournamentCity & "', '" & t.TournamentCountry & "');")
    End Function

    Public Function InsertEdition(edition As Editions) As Integer
        Return DBBroker.GetBroker.Change("INSERT INTO Editions VALUES ('" & edition.year & "','" & edition.tournament & "', '" & edition.winner & "');")
    End Function

    Friend Sub ReadByName(ByVal t As Tournament)
        Dim col As Collection : Dim aux As Collection
        col = DBBroker.GetBroker.Read("SELECT * FROM Tournaments WHERE TournamentName='" & t.TournamentName & "';")
        For Each aux In col
            t.idTournament = CInt(aux(1).ToString)
            t.TournamentCity = aux(3).ToString
            t.TournamentCountry = aux(4).ToString
        Next
    End Sub

    Public Function Update(ByVal t As Tournament) As Integer
        Return DBBroker.GetBroker.Change("UPDATE Tournaments SET TournamentName='" & t.TournamentName & "', TournamentCity= '" & t.TournamentCity & "', TournamentCountry= '" & t.TournamentCountry & "' WHERE idTournament='" & t.idTournament & "';")
    End Function

    Public Function Delete(ByVal t As Tournament) As Integer
        Return DBBroker.GetBroker.Change("DELETE FROM Tournaments WHERE idTournament='" & t.idTournament & "';")
    End Function

End Class
