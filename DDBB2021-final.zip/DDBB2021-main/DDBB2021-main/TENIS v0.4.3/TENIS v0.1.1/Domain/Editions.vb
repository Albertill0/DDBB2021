﻿Public Class Editions
    Property year As Integer
    Property tournament As Integer
    Property winner As Integer


End Class
