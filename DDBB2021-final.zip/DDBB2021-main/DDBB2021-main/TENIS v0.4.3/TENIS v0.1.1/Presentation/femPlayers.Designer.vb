﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class femPlayers
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.listaID = New System.Windows.Forms.ListBox()
        Me.InsertBT = New System.Windows.Forms.Button()
        Me.UpdateBT = New System.Windows.Forms.Button()
        Me.DeleteBT = New System.Windows.Forms.Button()
        Me.ClearBT = New System.Windows.Forms.Button()
        Me.NameTB = New System.Windows.Forms.TextBox()
        Me.PointsTB = New System.Windows.Forms.TextBox()
        Me.PlayernameLB = New System.Windows.Forms.Label()
        Me.PointsLabel = New System.Windows.Forms.Label()
        Me.DateLabel = New System.Windows.Forms.Label()
        Me.Country = New System.Windows.Forms.Label()
        Me.birthpicker = New System.Windows.Forms.DateTimePicker()
        Me.MenuBT = New System.Windows.Forms.Button()
        Me.comboCountries = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.yearList = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.comboTournaments = New System.Windows.Forms.ComboBox()
        Me.ResultList = New System.Windows.Forms.ListBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.listaTORNEOS = New System.Windows.Forms.ListBox()
        Me.listaRondas = New System.Windows.Forms.ListBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.comboFechas = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ShowRankingBTN = New System.Windows.Forms.Button()
        Me.LstFinals = New System.Windows.Forms.ListBox()
        Me.LstWins = New System.Windows.Forms.ListBox()
        Me.LstPPoints = New System.Windows.Forms.ListBox()
        Me.LstPNames = New System.Windows.Forms.ListBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'listaID
        '
        Me.listaID.FormattingEnabled = True
        Me.listaID.ItemHeight = 16
        Me.listaID.Location = New System.Drawing.Point(63, 65)
        Me.listaID.Name = "listaID"
        Me.listaID.Size = New System.Drawing.Size(192, 340)
        Me.listaID.TabIndex = 0
        '
        'InsertBT
        '
        Me.InsertBT.Location = New System.Drawing.Point(345, 272)
        Me.InsertBT.Name = "InsertBT"
        Me.InsertBT.Size = New System.Drawing.Size(75, 39)
        Me.InsertBT.TabIndex = 1
        Me.InsertBT.Text = "Insert"
        Me.InsertBT.UseVisualStyleBackColor = True
        '
        'UpdateBT
        '
        Me.UpdateBT.Location = New System.Drawing.Point(491, 272)
        Me.UpdateBT.Name = "UpdateBT"
        Me.UpdateBT.Size = New System.Drawing.Size(75, 40)
        Me.UpdateBT.TabIndex = 2
        Me.UpdateBT.Text = "Update"
        Me.UpdateBT.UseVisualStyleBackColor = True
        '
        'DeleteBT
        '
        Me.DeleteBT.Location = New System.Drawing.Point(345, 345)
        Me.DeleteBT.Name = "DeleteBT"
        Me.DeleteBT.Size = New System.Drawing.Size(75, 32)
        Me.DeleteBT.TabIndex = 3
        Me.DeleteBT.Text = "Delete"
        Me.DeleteBT.UseVisualStyleBackColor = True
        '
        'ClearBT
        '
        Me.ClearBT.Location = New System.Drawing.Point(491, 345)
        Me.ClearBT.Name = "ClearBT"
        Me.ClearBT.Size = New System.Drawing.Size(75, 32)
        Me.ClearBT.TabIndex = 4
        Me.ClearBT.Text = "Clear"
        Me.ClearBT.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ClearBT.UseVisualStyleBackColor = True
        '
        'NameTB
        '
        Me.NameTB.Location = New System.Drawing.Point(320, 127)
        Me.NameTB.Name = "NameTB"
        Me.NameTB.Size = New System.Drawing.Size(100, 22)
        Me.NameTB.TabIndex = 5
        '
        'PointsTB
        '
        Me.PointsTB.Location = New System.Drawing.Point(320, 180)
        Me.PointsTB.Name = "PointsTB"
        Me.PointsTB.Size = New System.Drawing.Size(100, 22)
        Me.PointsTB.TabIndex = 6
        '
        'PlayernameLB
        '
        Me.PlayernameLB.AutoSize = True
        Me.PlayernameLB.Location = New System.Drawing.Point(320, 85)
        Me.PlayernameLB.Name = "PlayernameLB"
        Me.PlayernameLB.Size = New System.Drawing.Size(85, 17)
        Me.PlayernameLB.TabIndex = 9
        Me.PlayernameLB.Text = "PlayerName"
        '
        'PointsLabel
        '
        Me.PointsLabel.AutoSize = True
        Me.PointsLabel.Location = New System.Drawing.Point(323, 156)
        Me.PointsLabel.Name = "PointsLabel"
        Me.PointsLabel.Size = New System.Drawing.Size(98, 17)
        Me.PointsLabel.TabIndex = 10
        Me.PointsLabel.Text = "Current Points"
        '
        'DateLabel
        '
        Me.DateLabel.AutoSize = True
        Me.DateLabel.Location = New System.Drawing.Point(494, 85)
        Me.DateLabel.Name = "DateLabel"
        Me.DateLabel.Size = New System.Drawing.Size(60, 17)
        Me.DateLabel.TabIndex = 11
        Me.DateLabel.Text = "Birthday"
        '
        'Country
        '
        Me.Country.AutoSize = True
        Me.Country.Location = New System.Drawing.Point(497, 156)
        Me.Country.Name = "Country"
        Me.Country.Size = New System.Drawing.Size(57, 17)
        Me.Country.TabIndex = 12
        Me.Country.Text = "Country"
        '
        'birthpicker
        '
        Me.birthpicker.CustomFormat = "yyyy/MM/dd"
        Me.birthpicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.birthpicker.Location = New System.Drawing.Point(491, 127)
        Me.birthpicker.Name = "birthpicker"
        Me.birthpicker.Size = New System.Drawing.Size(121, 22)
        Me.birthpicker.TabIndex = 13
        '
        'MenuBT
        '
        Me.MenuBT.Location = New System.Drawing.Point(12, 12)
        Me.MenuBT.Name = "MenuBT"
        Me.MenuBT.Size = New System.Drawing.Size(75, 23)
        Me.MenuBT.TabIndex = 14
        Me.MenuBT.Text = "Menu"
        Me.MenuBT.UseVisualStyleBackColor = True
        '
        'comboCountries
        '
        Me.comboCountries.FormattingEnabled = True
        Me.comboCountries.Location = New System.Drawing.Point(491, 180)
        Me.comboCountries.Name = "comboCountries"
        Me.comboCountries.Size = New System.Drawing.Size(121, 24)
        Me.comboCountries.TabIndex = 15
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.yearList)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.comboTournaments)
        Me.GroupBox1.Controls.Add(Me.ResultList)
        Me.GroupBox1.Location = New System.Drawing.Point(699, 55)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(443, 364)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "RESULTS CHART FOR SPECIFIED TOURNAMENT"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 18)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(420, 17)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Select a player from the list and the tournament to see the results"
        '
        'yearList
        '
        Me.yearList.FormattingEnabled = True
        Me.yearList.ItemHeight = 16
        Me.yearList.Location = New System.Drawing.Point(157, 92)
        Me.yearList.Name = "yearList"
        Me.yearList.Size = New System.Drawing.Size(120, 244)
        Me.yearList.TabIndex = 19
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(280, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 17)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "Tournaments"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 17)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Results"
        '
        'comboTournaments
        '
        Me.comboTournaments.FormattingEnabled = True
        Me.comboTournaments.Location = New System.Drawing.Point(283, 92)
        Me.comboTournaments.Name = "comboTournaments"
        Me.comboTournaments.Size = New System.Drawing.Size(121, 24)
        Me.comboTournaments.TabIndex = 1
        '
        'ResultList
        '
        Me.ResultList.FormattingEnabled = True
        Me.ResultList.ItemHeight = 16
        Me.ResultList.Location = New System.Drawing.Point(16, 92)
        Me.ResultList.Name = "ResultList"
        Me.ResultList.Size = New System.Drawing.Size(120, 244)
        Me.ResultList.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.listaTORNEOS)
        Me.GroupBox2.Controls.Add(Me.listaRondas)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.comboFechas)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(699, 450)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(443, 300)
        Me.GroupBox2.TabIndex = 17
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "RESULT CHART BY SELECTED YEAR"
        '
        'listaTORNEOS
        '
        Me.listaTORNEOS.FormattingEnabled = True
        Me.listaTORNEOS.ItemHeight = 16
        Me.listaTORNEOS.Location = New System.Drawing.Point(157, 98)
        Me.listaTORNEOS.Name = "listaTORNEOS"
        Me.listaTORNEOS.Size = New System.Drawing.Size(120, 180)
        Me.listaTORNEOS.TabIndex = 25
        '
        'listaRondas
        '
        Me.listaRondas.FormattingEnabled = True
        Me.listaRondas.ItemHeight = 16
        Me.listaRondas.Location = New System.Drawing.Point(16, 98)
        Me.listaRondas.Name = "listaRondas"
        Me.listaRondas.Size = New System.Drawing.Size(120, 180)
        Me.listaRondas.TabIndex = 24
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 46)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(376, 17)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "Select a player from the list and the date to see the results"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(289, 78)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 17)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "Dates"
        '
        'comboFechas
        '
        Me.comboFechas.FormattingEnabled = True
        Me.comboFechas.Location = New System.Drawing.Point(292, 98)
        Me.comboFechas.Name = "comboFechas"
        Me.comboFechas.Size = New System.Drawing.Size(145, 24)
        Me.comboFechas.TabIndex = 22
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 78)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 17)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Results"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.ShowRankingBTN)
        Me.GroupBox3.Controls.Add(Me.LstFinals)
        Me.GroupBox3.Controls.Add(Me.LstWins)
        Me.GroupBox3.Controls.Add(Me.LstPPoints)
        Me.GroupBox3.Controls.Add(Me.LstPNames)
        Me.GroupBox3.Location = New System.Drawing.Point(63, 424)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(565, 326)
        Me.GroupBox3.TabIndex = 18
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "PLAYERS RANKING"
        '
        'ShowRankingBTN
        '
        Me.ShowRankingBTN.Location = New System.Drawing.Point(199, 21)
        Me.ShowRankingBTN.Name = "ShowRankingBTN"
        Me.ShowRankingBTN.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.ShowRankingBTN.Size = New System.Drawing.Size(159, 43)
        Me.ShowRankingBTN.TabIndex = 22
        Me.ShowRankingBTN.Text = "SHOW RANKING"
        Me.ShowRankingBTN.UseVisualStyleBackColor = True
        '
        'LstFinals
        '
        Me.LstFinals.FormattingEnabled = True
        Me.LstFinals.ItemHeight = 16
        Me.LstFinals.Location = New System.Drawing.Point(411, 104)
        Me.LstFinals.Name = "LstFinals"
        Me.LstFinals.Size = New System.Drawing.Size(126, 212)
        Me.LstFinals.TabIndex = 21
        '
        'LstWins
        '
        Me.LstWins.FormattingEnabled = True
        Me.LstWins.ItemHeight = 16
        Me.LstWins.Location = New System.Drawing.Point(279, 104)
        Me.LstWins.Name = "LstWins"
        Me.LstWins.Size = New System.Drawing.Size(126, 212)
        Me.LstWins.TabIndex = 20
        '
        'LstPPoints
        '
        Me.LstPPoints.FormattingEnabled = True
        Me.LstPPoints.ItemHeight = 16
        Me.LstPPoints.Location = New System.Drawing.Point(147, 104)
        Me.LstPPoints.Name = "LstPPoints"
        Me.LstPPoints.Size = New System.Drawing.Size(126, 212)
        Me.LstPPoints.TabIndex = 19
        '
        'LstPNames
        '
        Me.LstPNames.FormattingEnabled = True
        Me.LstPNames.ItemHeight = 16
        Me.LstPNames.Location = New System.Drawing.Point(15, 104)
        Me.LstPNames.Name = "LstPNames"
        Me.LstPNames.Size = New System.Drawing.Size(126, 212)
        Me.LstPNames.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 72)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 17)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "NAMES"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(144, 72)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 17)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "POINTS"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(279, 72)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(43, 17)
        Me.Label9.TabIndex = 25
        Me.Label9.Text = "WINS"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(408, 72)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(55, 17)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "FINALS"
        '
        'femPlayers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1197, 777)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.comboCountries)
        Me.Controls.Add(Me.MenuBT)
        Me.Controls.Add(Me.birthpicker)
        Me.Controls.Add(Me.Country)
        Me.Controls.Add(Me.DateLabel)
        Me.Controls.Add(Me.PointsLabel)
        Me.Controls.Add(Me.PlayernameLB)
        Me.Controls.Add(Me.PointsTB)
        Me.Controls.Add(Me.NameTB)
        Me.Controls.Add(Me.ClearBT)
        Me.Controls.Add(Me.DeleteBT)
        Me.Controls.Add(Me.UpdateBT)
        Me.Controls.Add(Me.InsertBT)
        Me.Controls.Add(Me.listaID)
        Me.Name = "femPlayers"
        Me.Text = "femPlayers"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents listaID As ListBox
    Friend WithEvents InsertBT As Button
    Friend WithEvents UpdateBT As Button
    Friend WithEvents DeleteBT As Button
    Friend WithEvents ClearBT As Button
    Friend WithEvents NameTB As TextBox
    Friend WithEvents PointsTB As TextBox
    Friend WithEvents PlayernameLB As Label
    Friend WithEvents PointsLabel As Label
    Friend WithEvents DateLabel As Label
    Friend WithEvents Country As Label
    Friend WithEvents birthpicker As DateTimePicker
    Friend WithEvents MenuBT As Button
    Friend WithEvents comboCountries As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents yearList As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents comboTournaments As ComboBox
    Friend WithEvents ResultList As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents comboFechas As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents listaTORNEOS As ListBox
    Friend WithEvents listaRondas As ListBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents ShowRankingBTN As Button
    Friend WithEvents LstFinals As ListBox
    Friend WithEvents LstWins As ListBox
    Friend WithEvents LstPPoints As ListBox
    Friend WithEvents LstPNames As ListBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
End Class
