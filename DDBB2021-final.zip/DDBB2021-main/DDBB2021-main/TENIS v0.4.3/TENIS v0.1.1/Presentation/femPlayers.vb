﻿Public Class femPlayers
    Private femP As Player
    Private AuxCountry As Country
    Private Tournament As Tournament
    Private Sub listaNombreJugador_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaID.SelectedIndexChanged
        If listaID.SelectedIndex > -1 Then
            femP = New Player With {
            .PlayerName = CStr(listaID.SelectedItem)
        }
            Try
                femP.ReadPlayerByNamed()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try
            NameTB.Text = femP.PlayerName
            birthpicker.Value = femP.PlayerBirthdate
            PointsTB.Text = CStr(femP.PlayerPoints)
            comboCountries.Text = femP.PlayerCountry
            InsertBT.Enabled = False
            ClearBT.Enabled = True
            UpdateBT.Enabled = True
            DeleteBT.Enabled = True
            PointsTB.Enabled = True
        End If
    End Sub

    Private Sub InsertBT_Click(sender As Object, e As EventArgs) Handles InsertBT.Click
        If NameTB.Text IsNot "" Then
            femP = New Player With {
            .PlayerName = NameTB.Text,
            .PlayerPoints = Convert.ToInt32(PointsTB.Text),
            .PlayerCountry = AuxCountry.idCountry,
            .PlayerBirthdate = birthpicker.Value.Date
        }
            Try
                femP.InsertPlayer()
                listaID.Items.Clear()
                femPlayers_Load(sender, e)
            Catch ex As Exception
                MessageBox.Show("Impossible to insert player." + ex.Message, ex.Source)
            End Try
        End If
    End Sub

    Private Sub femPlayers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aux As Player
        femP = New Player()
        Try
            femP.ReadAllPlayers()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)

        End Try
        For Each aux In femP.PlayerDAO.Players
            listaID.Items.Add(aux.PlayerName)
        Next
        comboCountries.MaxLength = 3
        PointsTB.Text = "0"
        PointsTB.Enabled = False
        InsertBT.Enabled = True
        DeleteBT.Enabled = False
        UpdateBT.Enabled = False
        ClearBT.Enabled = True
        Dim auxc As Country
        AuxCountry = New Country()
        Try
            AuxCountry.ReadAllCountries()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        For Each auxc In AuxCountry.CountriesDAO.Countries_coll
            comboCountries.Items.Add(auxc.CountryName)
        Next
        Tournament = New Tournament
        Try
            Tournament.ReadAllTournaments()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        Dim auxct As Tournament
        For Each auxct In Tournament.TournamentDAO.Tournaments
            comboTournaments.Items.Add(auxct.TournamentName)
        Next
        Dim auxYear, i As Integer
        auxYear = 2022
        For i = 0 To 40
            comboFechas.Items.Add(auxYear + i)
        Next

    End Sub

    Private Sub ClearBT_Click(sender As Object, e As EventArgs) Handles ClearBT.Click
        NameTB.Text = ""
        PointsTB.Text = ""
        comboCountries.Text = ""
        InsertBT.Enabled = True
        UpdateBT.Enabled = False
        DeleteBT.Enabled = False
        PointsTB.Text = "0"
        PointsTB.Enabled = False
    End Sub

    Private Sub UpdateBT_Click(sender As Object, e As EventArgs) Handles UpdateBT.Click
        femP = New Player()
        femP.idPlayer = CInt(listaID.SelectedItem)
        femP.PlayerName = NameTB.Text
        femP.PlayerPoints = CInt(PointsTB.Text)
        femP.PlayerCountry = AuxCountry.idCountry
        femP.PlayerBirthdate = birthpicker.Value

        Try
            femP.UpdatePlayer()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try

        MessageBox.Show("Player updated properly")
    End Sub

    Private Sub DeleteBT_Click(sender As Object, e As EventArgs) Handles DeleteBT.Click
        If listaID.SelectedItem IsNot Nothing Then
            femP = New Player()
            femP.PlayerName = CStr(listaID.SelectedItem)
            Try
                femP.ReadPlayerByNamed()
                femP.DeletePlayer()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try
            MessageBox.Show("Deleted properly")
            comboCountries.Text = ""
            NameTB.Text = ""
            PointsTB.Text = "0"
            PointsTB.Enabled = False
            listaID.Items.Remove(listaID.SelectedItem)
            listaID.Refresh()
        End If
    End Sub

    Private Sub menu_Click(sender As Object, e As EventArgs) Handles MenuBT.Click
        Dim Main As New Main_Interface()
        Main.Activate()
        Main.ConnectionB.Enabled = False
        Main.playerB.Enabled = True
        Main.countryB.Enabled = True
        Main.tournamentB.Enabled = True
        Main.Show()
        Me.Hide()
    End Sub

    Private Sub comboCountries_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboCountries.SelectedIndexChanged
        AuxCountry = New Country
        AuxCountry.CountryName = CStr(comboCountries.SelectedItem)
        Try
            AuxCountry.ReadCountryByName()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        If NameTB.Text Is Nothing Or NameTB.Text = "" Then
            InsertBT.Enabled = False
            UpdateBT.Enabled = False
        End If
    End Sub

    Private Sub NameTB_TextChanged(sender As Object, e As EventArgs) Handles NameTB.TextChanged
        If NameTB.Text IsNot Nothing And NameTB.Text IsNot "" Then
            InsertBT.Enabled = True
            UpdateBT.Enabled = True
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboTournaments.SelectedIndexChanged
        ResultList.Items.Clear()
        yearList.Items.Clear()
        If listaID.SelectedItem IsNot Nothing Then
            femP = New Player
            femP.PlayerName = CStr(listaID.SelectedItem)
            Try
                femP.ReadPlayerByNamed()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try

            If comboTournaments.SelectedItem IsNot Nothing Then
                Tournament = New Tournament
                Tournament.TournamentName = CStr(comboTournaments.SelectedItem)
                Try
                    Tournament.ReadTournamentByName()
                    Tournament.showResults(femP.idPlayer)
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source)
                End Try

                Dim r As Char
                Dim y As Integer

                For Each r In Tournament.TournamentDAO.Rounds
                    ResultList.Items.Add(r)
                Next

                For Each y In Tournament.TournamentDAO.EditionDates
                    yearList.Items.Add(y)
                Next

            End If

        End If
    End Sub

    Private Sub comboFechas_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboFechas.SelectedIndexChanged
        If listaID.SelectedItem IsNot Nothing Then
            femP = New Player
            femP.PlayerName = CStr(listaID.SelectedItem)
            Try
                femP.ReadPlayerByNamed()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source)
            End Try
            If comboFechas.SelectedItem IsNot Nothing Then

                Try
                    femP.showResultbydate(CInt(comboFechas.SelectedItem))

                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source)
                End Try
                Dim r As Char
                Dim tName As String
                For Each r In femP.PlayerDAO.Rounds
                    listaRondas.Items.Add(r)
                Next

                For Each tName In femP.PlayerDAO.TNames
                    listaTORNEOS.Items.Add(tName)
                Next
            End If
        End If
    End Sub

    Private Sub ShowRankingBTN_Click(sender As Object, e As EventArgs) Handles ShowRankingBTN.Click
        femP = New Player
        Try
            femP.ShowRanking()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source)
        End Try
        Dim r As String
        Dim points As String
        Dim id As Integer
        Dim p As Player
        Dim finals As String
        Dim wins As String
        Dim fempl As New Player

        For Each r In femP.PlayerDAO.PNames
            LstPNames.Items.Add(r)
        Next

        For Each points In femP.PlayerDAO.PlayerPoints
            LstPPoints.Items.Add(points)
        Next
        For Each id In femP.PlayerDAO.PID
            fempl.countWins(id)
            LstWins.Items.Add(fempl.PlayerDAO.Nwins.Item(1))
        Next
        fempl = New Player
        For Each id In femP.PlayerDAO.PID
            fempl.countFinal(id)
            LstFinals.Items.Add(fempl.PlayerDAO.NFinals.Item(1))
        Next
    End Sub
End Class